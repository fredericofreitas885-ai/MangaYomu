package com.mangayomu.di

import com.mangayomu.data.repository.CategoryRepositoryImpl
import com.mangayomu.data.repository.ChapterRepositoryImpl
import com.mangayomu.data.repository.HistoryRepositoryImpl
import com.mangayomu.data.repository.MangaRepositoryImpl
import com.mangayomu.domain.repository.CategoryRepository
import com.mangayomu.domain.repository.ChapterRepository
import com.mangayomu.domain.repository.HistoryRepository
import com.mangayomu.domain.repository.MangaRepository
import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
abstract class RepositoryModule {

    @Binds
    @Singleton
    abstract fun bindMangaRepository(
        impl: MangaRepositoryImpl,
    ): MangaRepository

    @Binds
    @Singleton
    abstract fun bindChapterRepository(
        impl: ChapterRepositoryImpl,
    ): ChapterRepository

    @Binds
    @Singleton
    abstract fun bindHistoryRepository(
        impl: HistoryRepositoryImpl,
    ): HistoryRepository

    @Binds
    @Singleton
    abstract fun bindCategoryRepository(
        impl: CategoryRepositoryImpl,
    ): CategoryRepository
}
