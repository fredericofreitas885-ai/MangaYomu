package com.mangayomu.di

import com.mangayomu.data.source.MangaDexSource
import com.mangayomu.data.source.MangaKakalotSource
import com.mangayomu.data.source.SourceManager
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object SourceModule {

    @Provides
    @Singleton
    fun provideSourceManager(
        mangaDexSource: MangaDexSource,
        mangaKakalotSource: MangaKakalotSource
    ): SourceManager {
        return SourceManager(mangaDexSource, mangaKakalotSource)
    }
}
