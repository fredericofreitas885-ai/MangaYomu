package com.mangayomu.domain.model

data class Page(
    val index: Int,
    val imageUrl: String
)
