package com.mangayomu.domain.model

data class Chapter(
    val id: String,
    val mangaId: String,
    val title: String,
    val chapterNumber: Float = 0f,
    val volumeNumber: Int? = null,
    val scanlator: String = "",
    val dateUpload: Long = 0L,
    val url: String = "",
    val sourceId: String,
    val isRead: Boolean = false,
    val lastPageRead: Int = 0,
    val isDownloaded: Boolean = false
)
