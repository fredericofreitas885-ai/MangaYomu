package com.mangayomu.domain.model

data class Category(
    val id: Long = 0,
    val name: String,
    val order: Int = 0
)
