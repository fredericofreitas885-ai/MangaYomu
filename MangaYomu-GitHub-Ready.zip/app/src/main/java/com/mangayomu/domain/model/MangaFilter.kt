package com.mangayomu.domain.model

data class MangaFilter(
    val query: String = "",
    val genres: List<String> = emptyList(),
    val status: MangaStatus? = null,
    val sortBy: SortOrder = SortOrder.POPULAR
)

enum class SortOrder {
    POPULAR,
    LATEST,
    ALPHABETICAL
}
