package com.mangayomu.domain.repository

import com.mangayomu.domain.model.Manga
import kotlinx.coroutines.flow.Flow

interface MangaRepository {
    fun getLibraryManga(): Flow<List<Manga>>
    fun getMangaById(mangaId: String, sourceId: String): Flow<Manga?>
    suspend fun getMangaByIdSync(mangaId: String, sourceId: String): Manga?
    suspend fun getMangaById(mangaId: String): Manga?
    suspend fun addToLibrary(manga: Manga)
    suspend fun removeFromLibrary(mangaId: String)
    suspend fun isInLibrary(mangaId: String): Boolean
    suspend fun updateManga(manga: Manga)
    suspend fun insertManga(manga: Manga)
}
