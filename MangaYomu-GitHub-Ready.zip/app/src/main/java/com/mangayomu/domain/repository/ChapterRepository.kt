package com.mangayomu.domain.repository

import com.mangayomu.domain.model.Chapter
import kotlinx.coroutines.flow.Flow

interface ChapterRepository {
    fun getChaptersForManga(mangaId: String): Flow<List<Chapter>>
    suspend fun getChapterById(chapterId: String): Chapter?
    suspend fun saveChapters(chapters: List<Chapter>)
    suspend fun markChapterRead(chapterId: String, lastPageRead: Int)
    suspend fun markChapterUnread(chapterId: String)
    suspend fun markChapterDownloaded(chapterId: String, isDownloaded: Boolean)
    suspend fun updateChapter(chapter: Chapter)
    suspend fun deleteChaptersForManga(mangaId: String)
}
