package com.mangayomu.domain.model

data class Manga(
    val id: String,
    val title: String,
    val coverUrl: String,
    val author: String = "",
    val artist: String = "",
    val description: String = "",
    val genres: List<String> = emptyList(),
    val status: MangaStatus = MangaStatus.UNKNOWN,
    val sourceId: String,
    val url: String = "",
    val inLibrary: Boolean = false,
    val dateAdded: Long = 0L,
    val lastUpdate: Long = 0L
)

enum class MangaStatus(val value: String) {
    ONGOING("Ongoing"),
    COMPLETED("Completed"),
    HIATUS("Hiatus"),
    CANCELLED("Cancelled"),
    UNKNOWN("Unknown");

    companion object {
        fun fromValue(value: String): MangaStatus {
            return entries.firstOrNull { 
                it.name.equals(value, ignoreCase = true) || 
                it.value.equals(value, ignoreCase = true) 
            } ?: UNKNOWN
        }
    }
}
