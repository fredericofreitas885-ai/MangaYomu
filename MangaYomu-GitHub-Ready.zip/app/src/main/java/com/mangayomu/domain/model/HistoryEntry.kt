package com.mangayomu.domain.model

data class HistoryEntry(
    val id: Long = 0,
    val manga: Manga,
    val chapter: Chapter,
    val readAt: Long
)
