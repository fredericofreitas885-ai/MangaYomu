package com.mangayomu.domain.repository

import com.mangayomu.domain.model.HistoryEntry
import kotlinx.coroutines.flow.Flow

interface HistoryRepository {
    fun getHistory(): Flow<List<HistoryEntry>>
    suspend fun addToHistory(mangaId: String, chapterId: String, sourceId: String)
    suspend fun clearHistory()
    suspend fun removeFromHistory(mangaId: String)
}
