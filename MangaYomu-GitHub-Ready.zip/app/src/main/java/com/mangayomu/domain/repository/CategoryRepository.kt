package com.mangayomu.domain.repository

import com.mangayomu.domain.model.Category
import com.mangayomu.domain.model.Manga
import kotlinx.coroutines.flow.Flow

interface CategoryRepository {
    fun getCategories(): Flow<List<Category>>
    suspend fun createCategory(name: String, order: Int = 0)
    suspend fun deleteCategory(categoryId: Long)
    suspend fun updateCategory(categoryId: Long, name: String, order: Int)
    suspend fun addMangaToCategory(mangaId: String, categoryId: Long)
    suspend fun removeMangaFromCategory(mangaId: String, categoryId: Long)
    fun getMangaForCategory(categoryId: Long): Flow<List<Manga>>
    suspend fun getCategoriesForManga(mangaId: String): List<Category>
}
