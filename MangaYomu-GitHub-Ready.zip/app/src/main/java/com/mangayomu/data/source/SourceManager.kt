package com.mangayomu.data.source

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Manages all registered manga sources.
 *
 * Allows dynamic registration and unregistration of sources at runtime,
 * enabling users to add new manga websites/sources.
 */
@Singleton
class SourceManager @Inject constructor(
    mangaDexSource: MangaDexSource,
    mangaKakalotSource: MangaKakalotSource
) {

    private val _sourcesFlow = MutableStateFlow<List<MangaSource>>(
        listOf(
            mangaDexSource,
            mangaKakalotSource
        )
    )
    val sourcesFlow: StateFlow<List<MangaSource>> = _sourcesFlow.asStateFlow()

    /**
     * Returns all registered manga sources.
     */
    fun getAllSources(): List<MangaSource> {
        return _sourcesFlow.value
    }

    /**
     * Registers a new manga source dynamically.
     */
    fun registerSource(source: MangaSource) {
        _sourcesFlow.update { current ->
            if (current.none { it.id == source.id }) {
                current + source
            } else {
                current.map { if (it.id == source.id) source else it }
            }
        }
    }

    /**
     * Unregisters a manga source by ID.
     */
    fun unregisterSource(sourceId: String) {
        _sourcesFlow.update { current ->
            current.filter { it.id != sourceId }
        }
    }

    /**
     * Returns the source with the given [sourceId], or null if not found.
     */
    fun getSource(sourceId: String): MangaSource? {
        return _sourcesFlow.value.find { it.id == sourceId }
    }

    /**
     * Returns the source with the given [sourceId], throwing [IllegalArgumentException]
     * if not found.
     */
    fun getSourceOrThrow(sourceId: String): MangaSource {
        return getSource(sourceId)
            ?: throw IllegalArgumentException("Source not found: $sourceId")
    }

    /**
     * Returns all sources that match the given [language] (ISO 639-1 code).
     */
    fun getSourcesByLanguage(language: String): List<MangaSource> {
        return _sourcesFlow.value.filter { it.language == language }
    }

    /**
     * Returns the first source whose name matches the given [name] (case-insensitive),
     * or null if not found.
     */
    fun getSourceByName(name: String): MangaSource? {
        return _sourcesFlow.value.firstOrNull { it.name.equals(name, ignoreCase = true) }
    }

    /**
     * Returns all unique languages available among the registered sources.
     */
    fun getAvailableLanguages(): List<String> {
        return _sourcesFlow.value.map { it.language }.distinct().sorted()
    }

    /**
     * Returns the number of registered sources.
     */
    fun getSourceCount(): Int {
        return _sourcesFlow.value.size
    }

    /**
     * Checks whether a source with the given [sourceId] is registered.
     */
    fun hasSource(sourceId: String): Boolean {
        return _sourcesFlow.value.any { it.id == sourceId }
    }
}
