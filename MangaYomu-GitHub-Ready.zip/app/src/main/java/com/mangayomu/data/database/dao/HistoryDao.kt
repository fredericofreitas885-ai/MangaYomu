package com.mangayomu.data.database.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.mangayomu.data.database.entity.HistoryEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface HistoryDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertHistory(history: HistoryEntity)

    @Query("SELECT * FROM history ORDER BY readAt DESC")
    fun getAllHistory(): Flow<List<HistoryEntity>>

    @Query("DELETE FROM history")
    suspend fun clearAllHistory()

    @Query("DELETE FROM history WHERE mangaId = :mangaId")
    suspend fun deleteHistoryForManga(mangaId: String)

    @Query("SELECT * FROM history WHERE mangaId = :mangaId ORDER BY readAt DESC LIMIT 1")
    suspend fun getLatestHistoryForManga(mangaId: String): HistoryEntity?

    @Query("SELECT * FROM history WHERE mangaId = :mangaId AND chapterId = :chapterId LIMIT 1")
    suspend fun getHistoryEntry(mangaId: String, chapterId: String): HistoryEntity?
}
