package com.mangayomu.data.source

import com.mangayomu.domain.model.Chapter
import com.mangayomu.domain.model.Manga
import com.mangayomu.domain.model.MangaStatus
import com.mangayomu.domain.model.Page

/**
 * Core interface for manga sources. Implement this to add a new manga site/source.
 * This is the extensible system that allows adding new manga sources easily.
 *
 * Each source represents one manga website or API (e.g., MangaDex, MangaSee, etc.).
 * To add a new source:
 * 1. Create a class implementing this interface (or extend [HttpSource] for web-scraping sources).
 * 2. Register it in [SourceManager].
 */
interface MangaSource {
    /** Unique identifier for this source. */
    val id: String

    /** Human-readable name of this source. */
    val name: String

    /** ISO 639-1 language code (e.g. "en", "ja"). */
    val language: String

    /** Base URL of the source website or API. */
    val baseUrl: String

    /** Optional icon URL for the source. */
    val iconUrl: String get() = ""

    /**
     * Fetches a page of popular manga from the source.
     * @param page 0-indexed page number for pagination.
     */
    suspend fun getPopularManga(page: Int): MangaPage

    /**
     * Fetches a page of latest-updated manga from the source.
     * @param page 0-indexed page number for pagination.
     */
    suspend fun getLatestManga(page: Int): MangaPage

    /**
     * Searches for manga matching the given query and optional filters.
     * @param query Search string.
     * @param page 0-indexed page number for pagination.
     * @param filters Optional list of active filters.
     */
    suspend fun searchManga(
        query: String,
        page: Int,
        filters: List<SourceFilter> = emptyList()
    ): MangaPage

    /**
     * Fetches full details for a manga (description, genres, author, etc.).
     * The returned [Manga] should have all fields populated.
     */
    suspend fun getMangaDetails(manga: Manga): Manga

    /**
     * Fetches the complete chapter list for a manga.
     * Chapters should be returned in ascending order by chapter number.
     */
    suspend fun getChapterList(manga: Manga): List<Chapter>

    /**
     * Fetches the list of page image URLs for a given chapter.
     */
    suspend fun getPageList(chapter: Chapter): List<Page>

    /**
     * Returns the list of available filters for this source's search.
     */
    suspend fun getAvailableFilters(): List<SourceFilter>
}

/**
 * Represents a paginated response of manga from a source.
 */
data class MangaPage(
    val mangas: List<Manga>,
    val hasNextPage: Boolean
)

/**
 * Sealed class hierarchy for source-specific search filters.
 */
sealed class SourceFilter {
    data class Genre(
        val name: String,
        val id: String,
        val selected: Boolean = false
    ) : SourceFilter()

    data class Status(
        val name: String,
        val value: MangaStatus
    ) : SourceFilter()

    data class Sort(
        val name: String,
        val options: List<String>,
        val selected: Int = 0
    ) : SourceFilter()
}
