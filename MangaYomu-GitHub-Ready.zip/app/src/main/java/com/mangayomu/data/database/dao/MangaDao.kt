package com.mangayomu.data.database.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.mangayomu.data.database.entity.MangaEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface MangaDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertManga(manga: MangaEntity)

    @Update
    suspend fun updateManga(manga: MangaEntity)

    @Query("SELECT * FROM manga WHERE inLibrary = 1 ORDER BY dateAdded DESC")
    fun getLibraryManga(): Flow<List<MangaEntity>>

    @Query("SELECT * FROM manga WHERE id = :mangaId AND sourceId = :sourceId LIMIT 1")
    fun getMangaByIdAndSource(mangaId: String, sourceId: String): Flow<MangaEntity?>

    @Query("SELECT * FROM manga WHERE id = :mangaId AND sourceId = :sourceId LIMIT 1")
    suspend fun getMangaByIdAndSourceSync(mangaId: String, sourceId: String): MangaEntity?

    @Query("SELECT * FROM manga WHERE id = :mangaId LIMIT 1")
    suspend fun getMangaById(mangaId: String): MangaEntity?

    @Query("DELETE FROM manga WHERE id = :mangaId")
    suspend fun deleteManga(mangaId: String)

    @Query("UPDATE manga SET inLibrary = :inLibrary WHERE id = :mangaId")
    suspend fun updateInLibrary(mangaId: String, inLibrary: Boolean)

    @Query("UPDATE manga SET inLibrary = :inLibrary, dateAdded = :dateAdded WHERE id = :mangaId")
    suspend fun updateInLibraryWithDate(mangaId: String, inLibrary: Boolean, dateAdded: Long)

    @Query("SELECT EXISTS(SELECT 1 FROM manga WHERE id = :mangaId AND inLibrary = 1)")
    suspend fun isInLibrary(mangaId: String): Boolean

    @Query("UPDATE manga SET lastUpdate = :lastUpdate WHERE id = :mangaId AND sourceId = :sourceId")
    suspend fun updateLastUpdate(mangaId: String, sourceId: String, lastUpdate: Long)
}
