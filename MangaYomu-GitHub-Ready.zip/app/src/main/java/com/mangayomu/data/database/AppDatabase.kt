package com.mangayomu.data.database

import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.mangayomu.data.database.dao.CategoryDao
import com.mangayomu.data.database.dao.ChapterDao
import com.mangayomu.data.database.dao.HistoryDao
import com.mangayomu.data.database.dao.MangaDao
import com.mangayomu.data.database.entity.CategoryEntity
import com.mangayomu.data.database.entity.ChapterEntity
import com.mangayomu.data.database.entity.HistoryEntity
import com.mangayomu.data.database.entity.MangaCategoryCrossRef
import com.mangayomu.data.database.entity.MangaEntity

@Database(
    entities = [
        MangaEntity::class,
        ChapterEntity::class,
        HistoryEntity::class,
        CategoryEntity::class,
        MangaCategoryCrossRef::class
    ],
    version = 1,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {

    abstract fun mangaDao(): MangaDao
    abstract fun chapterDao(): ChapterDao
    abstract fun historyDao(): HistoryDao
    abstract fun categoryDao(): CategoryDao

    companion object {
        const val DATABASE_NAME = "mangayomu_database"
    }
}
