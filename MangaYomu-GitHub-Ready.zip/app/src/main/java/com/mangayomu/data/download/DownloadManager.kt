package com.mangayomu.data.download

import android.content.Context
import com.mangayomu.data.source.SourceManager
import com.mangayomu.domain.model.Chapter
import com.mangayomu.domain.model.Page
import com.mangayomu.domain.repository.ChapterRepository
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class DownloadManager @Inject constructor(
    @ApplicationContext private val context: Context,
    private val sourceManager: SourceManager,
    private val chapterRepository: ChapterRepository,
    private val okHttpClient: OkHttpClient,
) {

    private val _downloads = MutableStateFlow<List<Download>>(emptyList())
    val downloads: StateFlow<List<Download>> = _downloads.asStateFlow()

    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private val downloadQueue = Channel<DownloadRequest>(Channel.UNLIMITED)

    init {
        processQueue()
    }

    fun enqueue(request: DownloadRequest) {
        val download = Download(
            mangaId = request.mangaId,
            chapterId = request.chapterId,
            sourceId = request.sourceId,
            mangaTitle = request.mangaTitle,
            chapterTitle = request.chapterTitle,
            status = DownloadStatus.QUEUED,
            progress = 0,
        )
        _downloads.update { currentList -> currentList + download }
        scope.launch {
            downloadQueue.send(request)
        }
    }

    fun cancelDownload(chapterId: String) {
        _downloads.update { currentList ->
            currentList.filter { it.chapterId != chapterId }
        }
    }

    private fun processQueue() {
        scope.launch {
            for (request in downloadQueue) {
                val currentDownload = _downloads.value.find {
                    it.chapterId == request.chapterId
                }
                if (currentDownload == null) {
                    continue
                }
                downloadChapter(request)
            }
        }
    }

    private suspend fun downloadChapter(request: DownloadRequest) {
        updateDownloadStatus(request.chapterId, DownloadStatus.DOWNLOADING, 0)

        try {
            val source = sourceManager.getSource(request.sourceId)
            if (source == null) {
                updateDownloadStatus(request.chapterId, DownloadStatus.ERROR, 0)
                return
            }

            val chapter = chapterRepository.getChapterById(request.chapterId)
                ?: Chapter(
                    id = request.chapterId,
                    mangaId = request.mangaId,
                    title = request.chapterTitle,
                    sourceId = request.sourceId
                )

            val pages = source.getPageList(chapter)
            if (pages.isEmpty()) {
                updateDownloadStatus(request.chapterId, DownloadStatus.ERROR, 0)
                return
            }

            val downloadDir = getDownloadDirectory(request.mangaId, request.chapterId)
            downloadDir.mkdirs()

            pages.forEachIndexed { index, page ->
                val stillActive = _downloads.value.any { it.chapterId == request.chapterId }
                if (!stillActive) return

                val imageFile = File(downloadDir, "${index + 1}.jpg")
                downloadImage(page.imageUrl, imageFile)

                val progress = ((index + 1) * 100) / pages.size
                updateDownloadStatus(request.chapterId, DownloadStatus.DOWNLOADING, progress)
            }

            updateDownloadStatus(request.chapterId, DownloadStatus.COMPLETED, 100)
            chapterRepository.markChapterDownloaded(request.chapterId, true)
        } catch (e: Exception) {
            updateDownloadStatus(request.chapterId, DownloadStatus.ERROR, 0)
        }
    }

    private fun downloadImage(imageUrl: String, outputFile: File) {
        val request = Request.Builder()
            .url(imageUrl)
            .build()

        okHttpClient.newCall(request).execute().use { response ->
            if (!response.isSuccessful) {
                throw IllegalStateException("Failed to download image: ${response.code}")
            }

            response.body?.byteStream()?.use { inputStream ->
                outputFile.outputStream().use { outputStream ->
                    inputStream.copyTo(outputStream)
                }
            } ?: throw IllegalStateException("Response body is null")
        }
    }

    private fun updateDownloadStatus(
        chapterId: String,
        status: DownloadStatus,
        progress: Int,
    ) {
        _downloads.update { currentList ->
            currentList.map { download ->
                if (download.chapterId == chapterId) {
                    download.copy(status = status, progress = progress)
                } else {
                    download
                }
            }
        }
    }

    fun getDownloadDirectory(mangaId: String, chapterId: String): File {
        val externalDir = context.getExternalFilesDir(null)
            ?: context.filesDir
        return File(externalDir, "downloads/$mangaId/$chapterId")
    }

    fun isChapterDownloaded(mangaId: String, chapterId: String): Boolean {
        val dir = getDownloadDirectory(mangaId, chapterId)
        return dir.exists() && dir.listFiles()?.isNotEmpty() == true
    }

    fun getDownloadedPages(mangaId: String, chapterId: String): List<Page> {
        val dir = getDownloadDirectory(mangaId, chapterId)
        if (!dir.exists()) return emptyList()

        return dir.listFiles()
            ?.filter { it.isFile && it.extension in listOf("jpg", "jpeg", "png", "webp") }
            ?.sortedBy { it.nameWithoutExtension.toIntOrNull() ?: 0 }
            ?.mapIndexed { index, file ->
                Page(
                    index = index,
                    imageUrl = "file://${file.absolutePath}"
                )
            }
            ?: emptyList()
    }

    fun deleteDownload(mangaId: String, chapterId: String) {
        val dir = getDownloadDirectory(mangaId, chapterId)
        if (dir.exists()) {
            dir.deleteRecursively()
        }
        _downloads.update { currentList ->
            currentList.filter { it.chapterId != chapterId }
        }
        scope.launch {
            chapterRepository.markChapterDownloaded(chapterId, false)
        }
    }
}
