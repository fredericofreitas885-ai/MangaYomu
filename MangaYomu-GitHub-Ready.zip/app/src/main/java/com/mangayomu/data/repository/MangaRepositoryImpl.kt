package com.mangayomu.data.repository

import com.mangayomu.data.database.dao.MangaDao
import com.mangayomu.data.database.entity.MangaEntity
import com.mangayomu.domain.model.Manga
import com.mangayomu.domain.model.MangaStatus
import com.mangayomu.domain.repository.MangaRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class MangaRepositoryImpl @Inject constructor(
    private val mangaDao: MangaDao,
) : MangaRepository {

    override fun getLibraryManga(): Flow<List<Manga>> {
        return mangaDao.getLibraryManga().map { entities ->
            entities.map { it.toDomainModel() }
        }
    }

    override fun getMangaById(mangaId: String, sourceId: String): Flow<Manga?> {
        return mangaDao.getMangaByIdAndSource(mangaId, sourceId).map { it?.toDomainModel() }
    }

    override suspend fun getMangaByIdSync(mangaId: String, sourceId: String): Manga? {
        return mangaDao.getMangaByIdAndSourceSync(mangaId, sourceId)?.toDomainModel()
    }

    override suspend fun getMangaById(mangaId: String): Manga? {
        return mangaDao.getMangaById(mangaId)?.toDomainModel()
    }

    override suspend fun addToLibrary(manga: Manga) {
        val entity = manga.toEntity().copy(
            inLibrary = true,
            dateAdded = if (manga.dateAdded > 0L) manga.dateAdded else System.currentTimeMillis(),
        )
        mangaDao.insertManga(entity)
    }

    override suspend fun removeFromLibrary(mangaId: String) {
        val existing = mangaDao.getMangaById(mangaId) ?: return
        mangaDao.updateManga(existing.copy(inLibrary = false))
    }

    override suspend fun isInLibrary(mangaId: String): Boolean {
        return mangaDao.isInLibrary(mangaId)
    }

    override suspend fun updateManga(manga: Manga) {
        mangaDao.updateManga(manga.toEntity())
    }

    override suspend fun insertManga(manga: Manga) {
        mangaDao.insertManga(manga.toEntity())
    }
}

fun MangaEntity.toDomainModel(): Manga {
    return Manga(
        id = id,
        sourceId = sourceId,
        title = title,
        coverUrl = coverUrl,
        artist = artist,
        author = author,
        description = description,
        genres = genres,
        status = MangaStatus.fromValue(status),
        url = url,
        inLibrary = inLibrary,
        dateAdded = dateAdded,
        lastUpdate = lastUpdate,
    )
}

fun Manga.toEntity(): MangaEntity {
    return MangaEntity(
        id = id,
        sourceId = sourceId,
        title = title,
        coverUrl = coverUrl,
        artist = artist,
        author = author,
        description = description,
        genres = genres,
        status = status.name,
        url = url,
        inLibrary = inLibrary,
        dateAdded = dateAdded,
        lastUpdate = lastUpdate,
    )
}
