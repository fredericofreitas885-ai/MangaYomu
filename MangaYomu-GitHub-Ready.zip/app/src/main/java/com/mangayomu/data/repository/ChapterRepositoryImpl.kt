package com.mangayomu.data.repository

import com.mangayomu.data.database.dao.ChapterDao
import com.mangayomu.data.database.entity.ChapterEntity
import com.mangayomu.domain.model.Chapter
import com.mangayomu.domain.repository.ChapterRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ChapterRepositoryImpl @Inject constructor(
    private val chapterDao: ChapterDao,
) : ChapterRepository {

    override fun getChaptersForManga(mangaId: String): Flow<List<Chapter>> {
        return chapterDao.getChaptersForManga(mangaId).map { entities ->
            entities.map { it.toDomainModel() }
        }
    }

    override suspend fun getChapterById(chapterId: String): Chapter? {
        return chapterDao.getChapterById(chapterId)?.toDomainModel()
    }

    override suspend fun saveChapters(chapters: List<Chapter>) {
        val entities = chapters.map { it.toEntity() }
        chapterDao.insertAll(entities)
    }

    override suspend fun markChapterRead(chapterId: String, lastPageRead: Int) {
        val existing = chapterDao.getChapterById(chapterId) ?: return
        chapterDao.insertChapter(
            existing.copy(
                isRead = true,
                lastPageRead = lastPageRead
            )
        )
    }

    override suspend fun markChapterUnread(chapterId: String) {
        val existing = chapterDao.getChapterById(chapterId) ?: return
        chapterDao.insertChapter(
            existing.copy(
                isRead = false,
                lastPageRead = 0
            )
        )
    }

    override suspend fun markChapterDownloaded(chapterId: String, isDownloaded: Boolean) {
        chapterDao.updateDownloadedStatus(chapterId, isDownloaded)
    }

    override suspend fun updateChapter(chapter: Chapter) {
        chapterDao.insertChapter(chapter.toEntity())
    }

    override suspend fun deleteChaptersForManga(mangaId: String) {
        chapterDao.deleteChaptersForManga(mangaId)
    }
}

fun ChapterEntity.toDomainModel(): Chapter {
    return Chapter(
        id = id,
        mangaId = mangaId,
        title = title,
        chapterNumber = chapterNumber,
        volumeNumber = volumeNumber,
        scanlator = scanlator,
        dateUpload = dateUpload,
        url = url,
        sourceId = sourceId,
        isRead = isRead,
        lastPageRead = lastPageRead,
        isDownloaded = isDownloaded,
    )
}

fun Chapter.toEntity(): ChapterEntity {
    return ChapterEntity(
        id = id,
        mangaId = mangaId,
        title = title,
        chapterNumber = chapterNumber,
        volumeNumber = volumeNumber,
        scanlator = scanlator,
        dateUpload = dateUpload,
        url = url,
        sourceId = sourceId,
        isRead = isRead,
        lastPageRead = lastPageRead,
        isDownloaded = isDownloaded,
    )
}
