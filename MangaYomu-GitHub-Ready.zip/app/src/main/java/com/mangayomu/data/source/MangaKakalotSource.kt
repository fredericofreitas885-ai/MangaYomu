package com.mangayomu.data.source

import com.mangayomu.domain.model.Chapter
import com.mangayomu.domain.model.Manga
import com.mangayomu.domain.model.MangaStatus
import com.mangayomu.domain.model.Page
import okhttp3.OkHttpClient
import org.jsoup.nodes.Element
import java.net.URLEncoder
import javax.inject.Inject
import javax.inject.Singleton

/**
 * HTML-scraping implementation of [MangaSource] for MangaKakalot / Manganato.
 * Demonstrates how to create a source for any manga website using Jsoup.
 */
@Singleton
class MangaKakalotSource @Inject constructor(
    override val client: OkHttpClient
) : HttpSource() {

    override val id: String = "mangakakalot"
    override val name: String = "MangaKakalot"
    override val language: String = "en"
    override val baseUrl: String = "https://mangakakalot.com"
    override val iconUrl: String = "https://mangakakalot.com/favicon.ico"

    override suspend fun getPopularManga(page: Int): MangaPage {
        val url = "$baseUrl/manga_list?type=topview&category=all&state=all&page=${page + 1}"
        val doc = fetchDocument(url)
        val elements = doc.select(".list-truyen-item-wrap")

        val mangas = elements.map { parseMangaFromElement(it) }
        val hasNextPage = doc.select("a.page_select + a").isNotEmpty()
        return MangaPage(mangas = mangas, hasNextPage = hasNextPage)
    }

    override suspend fun getLatestManga(page: Int): MangaPage {
        val url = "$baseUrl/manga_list?type=latest&category=all&state=all&page=${page + 1}"
        val doc = fetchDocument(url)
        val elements = doc.select(".list-truyen-item-wrap")

        val mangas = elements.map { parseMangaFromElement(it) }
        val hasNextPage = doc.select("a.page_select + a").isNotEmpty()
        return MangaPage(mangas = mangas, hasNextPage = hasNextPage)
    }

    override suspend fun searchManga(
        query: String,
        page: Int,
        filters: List<SourceFilter>
    ): MangaPage {
        val encoded = URLEncoder.encode(query.replace(" ", "_"), "UTF-8")
        val url = "$baseUrl/search/$encoded?page=${page + 1}"
        val doc = fetchDocument(url)
        val elements = doc.select(".panel_story_list .story_item")

        val mangas = elements.map { element ->
            val titleEl = element.select(".story_name a").first()
            val mangaUrl = titleEl?.attr("href").orEmpty()
            val id = mangaUrl.substringAfterLast("/")
            val title = titleEl?.text().orEmpty()
            val coverUrl = element.select("img").attr("src")
            val author = element.select(".story_author").text()

            Manga(
                id = id,
                title = title,
                coverUrl = coverUrl,
                author = author,
                sourceId = id,
                url = mangaUrl
            )
        }

        val hasNextPage = doc.select(".page_select + a").isNotEmpty()
        return MangaPage(mangas = mangas, hasNextPage = hasNextPage)
    }

    override suspend fun getMangaDetails(manga: Manga): Manga {
        val doc = fetchDocument(manga.url.ifEmpty { "$baseUrl/manga/${manga.id}" })
        val title = doc.select(".story-info-right h1").text().ifEmpty { manga.title }
        val coverUrl = doc.select(".info-image img").attr("src").ifEmpty { manga.coverUrl }
        val description = doc.select("#panel-story-info-description").text()
        val genres = doc.select(".table-value a").map { it.text() }
        val author = doc.select(".table-value").firstOrNull()?.text().orEmpty()

        return manga.copy(
            title = title,
            coverUrl = coverUrl,
            description = description,
            genres = genres,
            author = author,
            status = MangaStatus.ONGOING
        )
    }

    override suspend fun getChapterList(manga: Manga): List<Chapter> {
        val doc = fetchDocument(manga.url.ifEmpty { "$baseUrl/manga/${manga.id}" })
        val elements = doc.select(".row-content-chapter li")

        return elements.mapIndexed { index, el ->
            val link = el.select("a.chapter-name")
            val chapterUrl = link.attr("href")
            val chapterTitle = link.text()
            val chapterId = chapterUrl.substringAfterLast("/")

            Chapter(
                id = chapterId,
                mangaId = manga.id,
                title = chapterTitle,
                chapterNumber = (elements.size - index).toFloat(),
                url = chapterUrl,
                sourceId = id
            )
        }.reversed()
    }

    override suspend fun getPageList(chapter: Chapter): List<Page> {
        val doc = fetchDocument(chapter.url)
        val elements = doc.select(".container-chapter-reader img")

        return elements.mapIndexed { index, img ->
            val pageUrl = img.attr("src")
            Page(
                index = index,
                imageUrl = pageUrl
            )
        }
    }

    override suspend fun getAvailableFilters(): List<SourceFilter> {
        return emptyList()
    }

    private fun parseMangaFromElement(element: Element): Manga {
        val titleEl = element.select("h3 a")
        val mangaUrl = titleEl.attr("href")
        val id = mangaUrl.substringAfterLast("/")
        val title = titleEl.text()
        val coverUrl = element.select("img").attr("src")

        return Manga(
            id = id,
            title = title,
            coverUrl = coverUrl,
            sourceId = this.id,
            url = mangaUrl
        )
    }
}
