package com.mangayomu.data.repository

import com.mangayomu.data.database.dao.CategoryDao
import com.mangayomu.data.database.dao.MangaDao
import com.mangayomu.data.database.entity.CategoryEntity
import com.mangayomu.data.database.entity.MangaCategoryCrossRef
import com.mangayomu.domain.model.Category
import com.mangayomu.domain.model.Manga
import com.mangayomu.domain.repository.CategoryRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class CategoryRepositoryImpl @Inject constructor(
    private val categoryDao: CategoryDao,
    private val mangaDao: MangaDao,
) : CategoryRepository {

    override suspend fun createCategory(name: String, order: Int) {
        val entity = CategoryEntity(
            id = 0,
            name = name,
            order = order,
        )
        categoryDao.insertCategory(entity)
    }

    override suspend fun deleteCategory(categoryId: Long) {
        categoryDao.deleteCategory(categoryId)
    }

    override suspend fun updateCategory(categoryId: Long, name: String, order: Int) {
        val entity = CategoryEntity(
            id = categoryId,
            name = name,
            order = order,
        )
        categoryDao.insertCategory(entity)
    }

    override fun getCategories(): Flow<List<Category>> {
        return categoryDao.getAllCategories().map { entities ->
            entities.map { it.toDomainModel() }
        }
    }

    override suspend fun addMangaToCategory(mangaId: String, categoryId: Long) {
        val crossRef = MangaCategoryCrossRef(
            mangaId = mangaId,
            categoryId = categoryId,
        )
        categoryDao.insertMangaCategoryCrossRef(crossRef)
    }

    override suspend fun removeMangaFromCategory(mangaId: String, categoryId: Long) {
        categoryDao.deleteMangaCategoryCrossRef(mangaId, categoryId)
    }

    override fun getMangaForCategory(categoryId: Long): Flow<List<Manga>> {
        return categoryDao.getMangaIdsForCategory(categoryId).map { mangaIds ->
            mangaIds.mapNotNull { mangaId ->
                mangaDao.getMangaById(mangaId)?.toDomainModel()
            }
        }
    }

    override suspend fun getCategoriesForManga(mangaId: String): List<Category> {
        val categoryIds = categoryDao.getCategoryIdsForManga(mangaId).first()
        return categoryIds.mapNotNull { categoryId ->
            categoryDao.getCategoryById(categoryId)?.toDomainModel()
        }
    }
}

fun CategoryEntity.toDomainModel(): Category {
    return Category(
        id = id,
        name = name,
        order = order,
    )
}

fun Category.toEntity(): CategoryEntity {
    return CategoryEntity(
        id = id,
        name = name,
        order = order,
    )
}
