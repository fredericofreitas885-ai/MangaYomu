package com.mangayomu.data.download

data class Download(
    val mangaId: String,
    val chapterId: String,
    val sourceId: String,
    val mangaTitle: String,
    val chapterTitle: String,
    val status: DownloadStatus,
    val progress: Int = 0,
)

enum class DownloadStatus {
    QUEUED,
    DOWNLOADING,
    COMPLETED,
    ERROR,
}

data class DownloadRequest(
    val mangaId: String,
    val chapterId: String,
    val sourceId: String,
    val mangaTitle: String,
    val chapterTitle: String,
)
