package com.mangayomu.data.source

import okhttp3.OkHttpClient
import okhttp3.Request
import org.jsoup.Jsoup
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Abstract base class for HTTP-based manga sources that use web scraping with Jsoup.
 *
 * Subclasses should implement all [MangaSource] methods by using [fetchDocument]
 * to download and parse HTML pages, then extracting data with Jsoup selectors.
 *
 * For API-based sources (like MangaDex), implement [MangaSource] directly instead.
 */
abstract class HttpSource : MangaSource {

    /** OkHttpClient instance for making HTTP requests. */
    abstract val client: OkHttpClient

    /**
     * Fetches an HTML document from the given URL using OkHttp and parses it with Jsoup.
     *
     * @param url The full URL to fetch.
     * @return Parsed Jsoup [Document].
     * @throws IOException if the request fails or the response is not successful.
     */
    protected suspend fun fetchDocument(url: String): Document {
        return withContext(Dispatchers.IO) {
            val request = Request.Builder()
                .url(url)
                .header("User-Agent", USER_AGENT)
                .header("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
                .header("Accept-Language", "en-US,en;q=0.5")
                .build()

            val response = client.newCall(request).execute()

            if (!response.isSuccessful) {
                response.close()
                throw java.io.IOException("HTTP error ${response.code}: ${response.message}")
            }

            val body = response.body?.string()
                ?: throw java.io.IOException("Empty response body from $url")
            response.close()

            Jsoup.parse(body, url)
        }
    }

    /**
     * Fetches raw HTML/text content from a URL.
     *
     * @param url The full URL to fetch.
     * @return Raw response body string.
     */
    protected suspend fun fetchString(url: String): String {
        return withContext(Dispatchers.IO) {
            val request = Request.Builder()
                .url(url)
                .header("User-Agent", USER_AGENT)
                .build()

            val response = client.newCall(request).execute()

            if (!response.isSuccessful) {
                response.close()
                throw java.io.IOException("HTTP error ${response.code}: ${response.message}")
            }

            val body = response.body?.string()
                ?: throw java.io.IOException("Empty response body from $url")
            response.close()
            body
        }
    }

    /**
     * Extension function to select an element by CSS query and return its text content.
     * Returns an empty string if the element is not found.
     */
    protected fun Element.selectText(cssQuery: String): String {
        return this.select(cssQuery).firstOrNull()?.text().orEmpty()
    }

    /**
     * Extension function to select an element by CSS query and return a specified attribute.
     * Returns an empty string if the element or attribute is not found.
     */
    protected fun Element.selectAttr(cssQuery: String, attr: String): String {
        return this.select(cssQuery).firstOrNull()?.attr(attr).orEmpty()
    }

    /**
     * Extension function to select all elements matching a CSS query and return their text.
     */
    protected fun Element.selectTexts(cssQuery: String): List<String> {
        return this.select(cssQuery).map { it.text() }
    }

    /**
     * Resolves a potentially relative URL against the source's base URL.
     */
    protected fun resolveUrl(path: String): String {
        return when {
            path.startsWith("http://") || path.startsWith("https://") -> path
            path.startsWith("//") -> "https:$path"
            path.startsWith("/") -> "$baseUrl$path"
            else -> "$baseUrl/$path"
        }
    }

    companion object {
        private const val USER_AGENT =
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 " +
            "(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
    }
}
