package com.mangayomu.data.repository

import com.mangayomu.data.database.dao.ChapterDao
import com.mangayomu.data.database.dao.HistoryDao
import com.mangayomu.data.database.dao.MangaDao
import com.mangayomu.data.database.entity.HistoryEntity
import com.mangayomu.domain.model.HistoryEntry
import com.mangayomu.domain.repository.HistoryRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class HistoryRepositoryImpl @Inject constructor(
    private val historyDao: HistoryDao,
    private val mangaDao: MangaDao,
    private val chapterDao: ChapterDao,
) : HistoryRepository {

    override fun getHistory(): Flow<List<HistoryEntry>> {
        return historyDao.getAllHistory().map { historyEntities ->
            historyEntities.mapNotNull { historyEntity ->
                val manga = mangaDao.getMangaById(historyEntity.mangaId) ?: return@mapNotNull null
                val chapter = chapterDao.getChapterById(historyEntity.chapterId) ?: return@mapNotNull null

                HistoryEntry(
                    id = historyEntity.id,
                    manga = manga.toDomainModel(),
                    chapter = chapter.toDomainModel(),
                    readAt = historyEntity.readAt,
                )
            }
        }
    }

    override suspend fun addToHistory(
        mangaId: String,
        chapterId: String,
        sourceId: String,
    ) {
        val existingEntry = historyDao.getHistoryEntry(mangaId, chapterId)
        val now = System.currentTimeMillis()
        if (existingEntry != null) {
            historyDao.insertHistory(
                existingEntry.copy(readAt = now)
            )
        } else {
            val entity = HistoryEntity(
                id = 0,
                mangaId = mangaId,
                chapterId = chapterId,
                sourceId = sourceId,
                readAt = now,
            )
            historyDao.insertHistory(entity)
        }
    }

    override suspend fun clearHistory() {
        historyDao.clearAllHistory()
    }

    override suspend fun removeFromHistory(mangaId: String) {
        historyDao.deleteHistoryForManga(mangaId)
    }
}
