package com.mangayomu.data.database.entity

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index

@Entity(
    tableName = "chapters",
    primaryKeys = ["id", "mangaId"],
    foreignKeys = [
        ForeignKey(
            entity = MangaEntity::class,
            parentColumns = ["id", "sourceId"],
            childColumns = ["mangaId", "sourceId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [
        Index(value = ["mangaId", "sourceId"]),
        Index(value = ["mangaId"])
    ]
)
data class ChapterEntity(
    val id: String,
    val mangaId: String,
    val title: String,
    val chapterNumber: Float = 0f,
    val volumeNumber: Int? = null,
    val scanlator: String = "",
    val dateUpload: Long = 0L,
    val url: String = "",
    val sourceId: String,
    val isRead: Boolean = false,
    val lastPageRead: Int = 0,
    val isDownloaded: Boolean = false
)
