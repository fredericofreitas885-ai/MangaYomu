package com.mangayomu.data.source

import com.google.gson.Gson
import com.mangayomu.data.network.AtHomeResponse
import com.mangayomu.data.network.MangaDexChapter
import com.mangayomu.data.network.MangaDexCollection
import com.mangayomu.data.network.MangaDexManga
import com.mangayomu.data.network.MangaDexResponse
import com.mangayomu.data.network.Relationship
import com.mangayomu.domain.model.Chapter
import com.mangayomu.domain.model.Manga
import com.mangayomu.domain.model.MangaStatus
import com.mangayomu.domain.model.Page
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone
import javax.inject.Inject

/**
 * MangaDex API v5 implementation of [MangaSource].
 *
 * Provides access to the MangaDex manga catalog, chapter lists, and page images
 * via their public REST API.
 */
class MangaDexSource @Inject constructor(
    private val client: OkHttpClient,
    private val gson: Gson
) : MangaSource {

    override val id: String = "mangadex"
    override val name: String = "MangaDex"
    override val language: String = "en"
    override val baseUrl: String = "https://api.mangadex.org"
    override val iconUrl: String = "https://mangadex.org/favicon.ico"

    companion object {
        private const val COVERS_BASE_URL = "https://uploads.mangadex.org/covers"
        private const val DEFAULT_LIMIT = 20
        private const val CHAPTER_LIMIT = 100
    }

    // ── Popular Manga ────────────────────────────────────────────────────

    override suspend fun getPopularManga(page: Int): MangaPage {
        val offset = page * DEFAULT_LIMIT
        val url = "$baseUrl/manga" +
            "?order[followedCount]=desc" +
            "&limit=$DEFAULT_LIMIT" +
            "&offset=$offset" +
            "&includes[]=cover_art" +
            "&contentRating[]=safe" +
            "&contentRating[]=suggestive"

        val response = fetchApi<MangaDexCollection<MangaDexManga>>(url)
        val mangas = response.data.map { it.toDomainManga() }
        val hasNext = offset + DEFAULT_LIMIT < response.total
        return MangaPage(mangas = mangas, hasNextPage = hasNext)
    }

    // ── Latest Manga ─────────────────────────────────────────────────────

    override suspend fun getLatestManga(page: Int): MangaPage {
        val offset = page * DEFAULT_LIMIT
        val url = "$baseUrl/manga" +
            "?order[latestUploadedChapter]=desc" +
            "&limit=$DEFAULT_LIMIT" +
            "&offset=$offset" +
            "&includes[]=cover_art" +
            "&contentRating[]=safe" +
            "&contentRating[]=suggestive"

        val response = fetchApi<MangaDexCollection<MangaDexManga>>(url)
        val mangas = response.data.map { it.toDomainManga() }
        val hasNext = offset + DEFAULT_LIMIT < response.total
        return MangaPage(mangas = mangas, hasNextPage = hasNext)
    }

    // ── Search ───────────────────────────────────────────────────────────

    override suspend fun searchManga(
        query: String,
        page: Int,
        filters: List<SourceFilter>
    ): MangaPage {
        val offset = page * DEFAULT_LIMIT
        val sb = StringBuilder("$baseUrl/manga")
        sb.append("?title=${java.net.URLEncoder.encode(query, "UTF-8")}")
        sb.append("&limit=$DEFAULT_LIMIT")
        sb.append("&offset=$offset")
        sb.append("&includes[]=cover_art")
        sb.append("&contentRating[]=safe")
        sb.append("&contentRating[]=suggestive")

        // Apply filters
        for (filter in filters) {
            when (filter) {
                is SourceFilter.Genre -> {
                    if (filter.selected) {
                        sb.append("&includedTags[]=${filter.id}")
                    }
                }
                is SourceFilter.Status -> {
                    sb.append("&status[]=${filter.value.toMangaDexStatus()}")
                }
                is SourceFilter.Sort -> {
                    val sortOption = when (filter.selected) {
                        0 -> "order[followedCount]=desc"
                        1 -> "order[latestUploadedChapter]=desc"
                        2 -> "order[title]=asc"
                        else -> "order[followedCount]=desc"
                    }
                    sb.append("&$sortOption")
                }
            }
        }

        val response = fetchApi<MangaDexCollection<MangaDexManga>>(sb.toString())
        val mangas = response.data.map { it.toDomainManga() }
        val hasNext = offset + DEFAULT_LIMIT < response.total
        return MangaPage(mangas = mangas, hasNextPage = hasNext)
    }

    // ── Manga Details ────────────────────────────────────────────────────

    override suspend fun getMangaDetails(manga: Manga): Manga {
        val url = "$baseUrl/manga/${manga.id}" +
            "?includes[]=cover_art" +
            "&includes[]=author" +
            "&includes[]=artist"

        val response = fetchApi<MangaDexResponse<MangaDexManga>>(url)
        val mdManga = response.data
        val attributes = mdManga.attributes

        val title = attributes.title["en"]
            ?: attributes.title["ja-ro"]
            ?: attributes.title.values.firstOrNull()
            ?: manga.title

        val description = attributes.description["en"]
            ?: attributes.description.values.firstOrNull()
            ?: ""

        val genres = attributes.tags.mapNotNull { tag ->
            tag.attributes.name["en"]
        }

        val status = parseStatus(attributes.status)
        val coverUrl = extractCoverUrl(mdManga.id, mdManga.relationships)

        val authorName = extractRelationshipName(mdManga.relationships, "author")
        val artistName = extractRelationshipName(mdManga.relationships, "artist")

        return Manga(
            id = mdManga.id,
            title = title,
            coverUrl = coverUrl,
            author = authorName,
            artist = artistName,
            description = description,
            genres = genres,
            status = status,
            sourceId = id,
            url = "$baseUrl/manga/${mdManga.id}"
        )
    }

    // ── Chapter List ─────────────────────────────────────────────────────

    override suspend fun getChapterList(manga: Manga): List<Chapter> {
        val allChapters = mutableListOf<Chapter>()
        var offset = 0
        var hasMore = true

        while (hasMore) {
            val url = "$baseUrl/manga/${manga.id}/feed" +
                "?translatedLanguage[]=en" +
                "&order[chapter]=asc" +
                "&limit=$CHAPTER_LIMIT" +
                "&offset=$offset" +
                "&includes[]=scanlation_group"

            val response = fetchApi<MangaDexCollection<MangaDexChapter>>(url)

            val chapters = response.data.mapNotNull { mdChapter ->
                val attrs = mdChapter.attributes

                // Skip external chapters
                if (attrs.externalUrl != null) return@mapNotNull null

                val chapterNumber = attrs.chapter?.toFloatOrNull() ?: 0f
                val volumeNumber = attrs.volume?.toIntOrNull()
                val chapterTitle = attrs.title
                    ?: "Chapter ${attrs.chapter ?: "?"}"

                val dateUpload = parseIsoDate(attrs.publishAt)

                val scanlator = mdChapter.relationships
                    .firstOrNull { it.type == "scanlation_group" }
                    ?.let { rel ->
                        @Suppress("UNCHECKED_CAST")
                        (rel.attributes?.get("name") as? String) ?: ""
                    } ?: ""

                Chapter(
                    id = mdChapter.id,
                    mangaId = manga.id,
                    title = chapterTitle,
                    chapterNumber = chapterNumber,
                    volumeNumber = volumeNumber,
                    scanlator = scanlator,
                    dateUpload = dateUpload,
                    url = "$baseUrl/chapter/${mdChapter.id}",
                    sourceId = id
                )
            }

            allChapters.addAll(chapters)
            offset += CHAPTER_LIMIT
            hasMore = offset < response.total
        }

        return allChapters
    }

    // ── Page List ────────────────────────────────────────────────────────

    override suspend fun getPageList(chapter: Chapter): List<Page> {
        val url = "$baseUrl/at-home/server/${chapter.id}"
        val response = fetchApi<AtHomeResponse>(url)

        val serverBaseUrl = response.baseUrl
        val hash = response.chapter.hash
        val filenames = response.chapter.data

        return filenames.mapIndexed { index, filename ->
            Page(
                index = index,
                imageUrl = "$serverBaseUrl/data/$hash/$filename"
            )
        }
    }

    // ── Available Filters ────────────────────────────────────────────────

    override suspend fun getAvailableFilters(): List<SourceFilter> {
        val filters = mutableListOf<SourceFilter>()

        // Sort filter
        filters.add(
            SourceFilter.Sort(
                name = "Sort By",
                options = listOf("Popular", "Latest", "Alphabetical"),
                selected = 0
            )
        )

        // Status filters
        filters.add(SourceFilter.Status(name = "Ongoing", value = MangaStatus.ONGOING))
        filters.add(SourceFilter.Status(name = "Completed", value = MangaStatus.COMPLETED))
        filters.add(SourceFilter.Status(name = "Hiatus", value = MangaStatus.HIATUS))
        filters.add(SourceFilter.Status(name = "Cancelled", value = MangaStatus.CANCELLED))

        // Fetch genre tags from API
        try {
            val url = "$baseUrl/manga/tag"
            val tagResponse = fetchApi<MangaDexCollection<com.mangayomu.data.network.MangaDexTag>>(url)
            val genreTags = tagResponse.data
                .filter { it.attributes.group == "genre" || it.attributes.group == "theme" }
                .mapNotNull { tag ->
                    val tagName = tag.attributes.name["en"] ?: return@mapNotNull null
                    SourceFilter.Genre(name = tagName, id = tag.id)
                }
                .sortedBy { it.name }
            filters.addAll(genreTags)
        } catch (e: Exception) {
            // If tag fetching fails, provide a static list of common genres
            val commonGenres = listOf(
                "Action", "Adventure", "Comedy", "Drama", "Fantasy",
                "Horror", "Mystery", "Romance", "Sci-Fi", "Slice of Life",
                "Sports", "Supernatural", "Thriller", "Tragedy"
            )
            commonGenres.forEach { genre ->
                filters.add(SourceFilter.Genre(name = genre, id = genre.lowercase()))
            }
        }

        return filters
    }

    // ── Private Helpers ──────────────────────────────────────────────────

    /**
     * Makes an authenticated GET request to the MangaDex API and deserializes the response.
     */
    private suspend inline fun <reified T> fetchApi(url: String): T {
        return withContext(Dispatchers.IO) {
            val request = Request.Builder()
                .url(url)
                .header("Accept", "application/json")
                .header(
                    "User-Agent",
                    "MangaYomu/1.0 (Android; Kotlin; github.com/mangayomu)"
                )
                .get()
                .build()

            val response = client.newCall(request).execute()

            if (!response.isSuccessful) {
                val errorBody = response.body?.string() ?: ""
                response.close()
                throw IOException(
                    "MangaDex API error ${response.code}: ${response.message}. Body: $errorBody"
                )
            }

            val body = response.body?.string()
                ?: throw IOException("Empty response body from $url")
            response.close()

            try {
                gson.fromJson(body, T::class.java)
            } catch (e: Exception) {
                throw IOException("Failed to parse MangaDex response from $url", e)
            }
        }
    }

    /**
     * Converts a [MangaDexManga] API model to a domain [Manga].
     */
    private fun MangaDexManga.toDomainManga(): Manga {
        val title = attributes.title["en"]
            ?: attributes.title["ja-ro"]
            ?: attributes.title.values.firstOrNull()
            ?: "Unknown Title"

        val description = attributes.description["en"]
            ?: attributes.description.values.firstOrNull()
            ?: ""

        val genres = attributes.tags.mapNotNull { tag ->
            tag.attributes.name["en"]
        }

        val coverUrl = extractCoverUrl(this.id, this.relationships)
        val status = parseStatus(attributes.status)

        return Manga(
            id = this.id,
            title = title,
            coverUrl = coverUrl,
            description = description,
            genres = genres,
            status = status,
            sourceId = this@MangaDexSource.id,
            url = "$baseUrl/manga/${this.id}"
        )
    }

    /**
     * Extracts the cover image URL from a manga's relationships.
     */
    private fun extractCoverUrl(mangaId: String, relationships: List<Relationship>): String {
        val coverRelation = relationships.firstOrNull { it.type == "cover_art" }
        val fileName = coverRelation?.attributes?.get("fileName") as? String
        return if (fileName != null) {
            "$COVERS_BASE_URL/$mangaId/$fileName"
        } else {
            ""
        }
    }

    /**
     * Extracts the name from an author or artist relationship.
     */
    private fun extractRelationshipName(
        relationships: List<Relationship>,
        type: String
    ): String {
        val relation = relationships.firstOrNull { it.type == type }
        @Suppress("UNCHECKED_CAST")
        return (relation?.attributes?.get("name") as? String) ?: ""
    }

    /**
     * Parses the MangaDex status string to a domain [MangaStatus].
     */
    private fun parseStatus(status: String?): MangaStatus {
        return when (status?.lowercase()) {
            "ongoing" -> MangaStatus.ONGOING
            "completed" -> MangaStatus.COMPLETED
            "hiatus" -> MangaStatus.HIATUS
            "cancelled" -> MangaStatus.CANCELLED
            else -> MangaStatus.UNKNOWN
        }
    }

    /**
     * Converts a domain [MangaStatus] to the MangaDex API status string.
     */
    private fun MangaStatus.toMangaDexStatus(): String {
        return when (this) {
            MangaStatus.ONGOING -> "ongoing"
            MangaStatus.COMPLETED -> "completed"
            MangaStatus.HIATUS -> "hiatus"
            MangaStatus.CANCELLED -> "cancelled"
            MangaStatus.UNKNOWN -> "ongoing"
        }
    }

    /**
     * Parses an ISO 8601 date string to a Unix timestamp in milliseconds.
     */
    private fun parseIsoDate(dateStr: String): Long {
        return try {
            val format = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss+SS:SS", Locale.US).apply {
                timeZone = TimeZone.getTimeZone("UTC")
            }
            format.parse(dateStr)?.time ?: 0L
        } catch (e: Exception) {
            try {
                // Fallback: try a simpler format
                val fallbackFormat = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.US).apply {
                    timeZone = TimeZone.getTimeZone("UTC")
                }
                fallbackFormat.parse(dateStr)?.time ?: 0L
            } catch (e2: Exception) {
                0L
            }
        }
    }

    /**
     * Re-using the network model tag type for filter fetching.
     */
    private data class MangaDexTag(
        val id: String,
        val attributes: MangaDexTagAttr
    )

    private data class MangaDexTagAttr(
        val name: Map<String, String>,
        val group: String
    )
}
