package com.mangayomu.data.database.entity

import androidx.room.Entity
import androidx.room.TypeConverters
import com.mangayomu.data.database.Converters

@Entity(
    tableName = "manga",
    primaryKeys = ["id", "sourceId"]
)
@TypeConverters(Converters::class)
data class MangaEntity(
    val id: String,
    val title: String,
    val coverUrl: String,
    val author: String = "",
    val artist: String = "",
    val description: String = "",
    val genres: List<String> = emptyList(),
    val status: String = "UNKNOWN",
    val sourceId: String,
    val url: String = "",
    val inLibrary: Boolean = false,
    val dateAdded: Long = 0L,
    val lastUpdate: Long = 0L
)
