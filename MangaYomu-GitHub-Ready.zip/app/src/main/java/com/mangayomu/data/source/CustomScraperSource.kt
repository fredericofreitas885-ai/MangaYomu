package com.mangayomu.data.source

import com.mangayomu.domain.model.Chapter
import com.mangayomu.domain.model.Manga
import com.mangayomu.domain.model.MangaStatus
import com.mangayomu.domain.model.Page
import okhttp3.OkHttpClient
import java.net.URLEncoder

/**
 * Configuration model for custom user-added manga sources.
 * Allows adding new sites dynamically without writing new code!
 */
data class CustomSourceConfig(
    val id: String,
    val name: String,
    val baseUrl: String,
    val language: String = "en",
    val popularPath: String = "",
    val latestPath: String = "",
    val searchPath: String = "", // e.g. "/search?q={query}&page={page}"
    val mangaItemSelector: String = ".manga-item",
    val titleSelector: String = ".title a",
    val coverSelector: String = "img",
    val coverAttr: String = "src",
    val urlSelector: String = ".title a",
    val chapterListSelector: String = ".chapter-list li a",
    val pageImageSelector: String = ".reader-images img"
)

/**
 * Generic configurable source that parses any website according to [CustomSourceConfig].
 */
class CustomScraperSource(
    override val client: OkHttpClient,
    val config: CustomSourceConfig
) : HttpSource() {

    override val id: String = config.id
    override val name: String = config.name
    override val language: String = config.language
    override val baseUrl: String = config.baseUrl

    override suspend fun getPopularManga(page: Int): MangaPage {
        val url = resolveUrl(config.popularPath.replace("{page}", "${page + 1}"))
        val doc = fetchDocument(url)
        val elements = doc.select(config.mangaItemSelector)

        val mangas = elements.map { el ->
            val title = el.selectText(config.titleSelector)
            val coverUrl = el.selectAttr(config.coverSelector, config.coverAttr)
            val link = el.selectAttr(config.urlSelector, "href")
            Manga(
                id = link.substringAfterLast("/").ifEmpty { title.hashCode().toString() },
                title = title,
                coverUrl = resolveUrl(coverUrl),
                sourceId = id,
                url = resolveUrl(link)
            )
        }
        return MangaPage(mangas = mangas, hasNextPage = mangas.isNotEmpty())
    }

    override suspend fun getLatestManga(page: Int): MangaPage {
        val url = resolveUrl(config.latestPath.replace("{page}", "${page + 1}"))
        val doc = fetchDocument(url)
        val elements = doc.select(config.mangaItemSelector)

        val mangas = elements.map { el ->
            val title = el.selectText(config.titleSelector)
            val coverUrl = el.selectAttr(config.coverSelector, config.coverAttr)
            val link = el.selectAttr(config.urlSelector, "href")
            Manga(
                id = link.substringAfterLast("/").ifEmpty { title.hashCode().toString() },
                title = title,
                coverUrl = resolveUrl(coverUrl),
                sourceId = id,
                url = resolveUrl(link)
            )
        }
        return MangaPage(mangas = mangas, hasNextPage = mangas.isNotEmpty())
    }

    override suspend fun searchManga(
        query: String,
        page: Int,
        filters: List<SourceFilter>
    ): MangaPage {
        val encodedQuery = URLEncoder.encode(query, "UTF-8")
        val searchUrl = config.searchPath
            .replace("{query}", encodedQuery)
            .replace("{page}", "${page + 1}")
        val url = resolveUrl(searchUrl)
        val doc = fetchDocument(url)
        val elements = doc.select(config.mangaItemSelector)

        val mangas = elements.map { el ->
            val title = el.selectText(config.titleSelector)
            val coverUrl = el.selectAttr(config.coverSelector, config.coverAttr)
            val link = el.selectAttr(config.urlSelector, "href")
            Manga(
                id = link.substringAfterLast("/").ifEmpty { title.hashCode().toString() },
                title = title,
                coverUrl = resolveUrl(coverUrl),
                sourceId = id,
                url = resolveUrl(link)
            )
        }
        return MangaPage(mangas = mangas, hasNextPage = mangas.isNotEmpty())
    }

    override suspend fun getMangaDetails(manga: Manga): Manga {
        val doc = fetchDocument(manga.url)
        val title = doc.select("h1").firstOrNull()?.text() ?: manga.title
        val desc = doc.select(".description, #description, p").firstOrNull()?.text().orEmpty()
        return manga.copy(title = title, description = desc, status = MangaStatus.ONGOING)
    }

    override suspend fun getChapterList(manga: Manga): List<Chapter> {
        val doc = fetchDocument(manga.url)
        val elements = doc.select(config.chapterListSelector)

        return elements.mapIndexed { index, el ->
            val chapterUrl = resolveUrl(el.attr("href"))
            val title = el.text().ifEmpty { "Chapter ${index + 1}" }
            Chapter(
                id = chapterUrl.substringAfterLast("/").ifEmpty { "ch_$index" },
                mangaId = manga.id,
                title = title,
                chapterNumber = (index + 1).toFloat(),
                url = chapterUrl,
                sourceId = id
            )
        }
    }

    override suspend fun getPageList(chapter: Chapter): List<Page> {
        val doc = fetchDocument(chapter.url)
        val elements = doc.select(config.pageImageSelector)

        return elements.mapIndexed { index, el ->
            val imgUrl = el.attr("data-src").ifEmpty { el.attr("src") }
            Page(
                index = index,
                imageUrl = resolveUrl(imgUrl)
            )
        }
    }

    override suspend fun getAvailableFilters(): List<SourceFilter> = emptyList()
}
