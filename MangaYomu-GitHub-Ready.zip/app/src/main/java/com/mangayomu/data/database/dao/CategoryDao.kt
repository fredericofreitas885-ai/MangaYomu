package com.mangayomu.data.database.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.mangayomu.data.database.entity.CategoryEntity
import com.mangayomu.data.database.entity.MangaCategoryCrossRef
import kotlinx.coroutines.flow.Flow

@Dao
interface CategoryDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCategory(category: CategoryEntity): Long

    @Query("DELETE FROM categories WHERE id = :categoryId")
    suspend fun deleteCategory(categoryId: Long)

    @Query("SELECT * FROM categories ORDER BY `order` ASC")
    fun getAllCategories(): Flow<List<CategoryEntity>>

    @Query("SELECT * FROM categories WHERE id = :categoryId LIMIT 1")
    suspend fun getCategoryById(categoryId: Long): CategoryEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMangaCategoryCrossRef(crossRef: MangaCategoryCrossRef)

    @Query("DELETE FROM manga_category_cross_ref WHERE mangaId = :mangaId AND categoryId = :categoryId")
    suspend fun deleteMangaCategoryCrossRef(mangaId: String, categoryId: Long)

    @Query("SELECT mangaId FROM manga_category_cross_ref WHERE categoryId = :categoryId")
    fun getMangaIdsForCategory(categoryId: Long): Flow<List<String>>

    @Query("SELECT categoryId FROM manga_category_cross_ref WHERE mangaId = :mangaId")
    fun getCategoryIdsForManga(mangaId: String): Flow<List<Long>>

    @Query("UPDATE categories SET `order` = :order WHERE id = :categoryId")
    suspend fun updateCategoryOrder(categoryId: Long, order: Int)
}
