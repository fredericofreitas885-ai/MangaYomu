package com.mangayomu.data.network

import com.google.gson.annotations.SerializedName

/**
 * Top-level response wrapper for single-entity MangaDex API v5 responses.
 */
data class MangaDexResponse<T>(
    @SerializedName("result") val result: String,
    @SerializedName("response") val response: String,
    @SerializedName("data") val data: T
)

/**
 * Top-level response wrapper for collection (list) MangaDex API v5 responses.
 */
data class MangaDexCollection<T>(
    @SerializedName("result") val result: String,
    @SerializedName("response") val response: String,
    @SerializedName("data") val data: List<T>,
    @SerializedName("limit") val limit: Int,
    @SerializedName("offset") val offset: Int,
    @SerializedName("total") val total: Int
)

/**
 * Represents a MangaDex manga entity with its attributes and relationships.
 */
data class MangaDexManga(
    @SerializedName("id") val id: String,
    @SerializedName("type") val type: String,
    @SerializedName("attributes") val attributes: MangaDexMangaAttributes,
    @SerializedName("relationships") val relationships: List<Relationship> = emptyList()
)

data class MangaDexMangaAttributes(
    @SerializedName("title") val title: Map<String, String>,
    @SerializedName("altTitles") val altTitles: List<Map<String, String>> = emptyList(),
    @SerializedName("description") val description: Map<String, String> = emptyMap(),
    @SerializedName("isLocked") val isLocked: Boolean = false,
    @SerializedName("links") val links: Map<String, String>? = null,
    @SerializedName("originalLanguage") val originalLanguage: String = "",
    @SerializedName("lastVolume") val lastVolume: String? = null,
    @SerializedName("lastChapter") val lastChapter: String? = null,
    @SerializedName("publicationDemographic") val publicationDemographic: String? = null,
    @SerializedName("status") val status: String? = null,
    @SerializedName("year") val year: Int? = null,
    @SerializedName("contentRating") val contentRating: String? = null,
    @SerializedName("tags") val tags: List<MangaDexTag> = emptyList(),
    @SerializedName("state") val state: String = "",
    @SerializedName("createdAt") val createdAt: String = "",
    @SerializedName("updatedAt") val updatedAt: String = "",
    @SerializedName("availableTranslatedLanguages") val availableTranslatedLanguages: List<String?> = emptyList(),
    @SerializedName("latestUploadedChapter") val latestUploadedChapter: String? = null
)

data class MangaDexTag(
    @SerializedName("id") val id: String,
    @SerializedName("type") val type: String = "tag",
    @SerializedName("attributes") val attributes: MangaDexTagAttributes
)

data class MangaDexTagAttributes(
    @SerializedName("name") val name: Map<String, String>,
    @SerializedName("description") val description: Map<String, String> = emptyMap(),
    @SerializedName("group") val group: String = "",
    @SerializedName("version") val version: Int = 1
)

/**
 * Represents a MangaDex chapter entity with its attributes and relationships.
 */
data class MangaDexChapter(
    @SerializedName("id") val id: String,
    @SerializedName("type") val type: String,
    @SerializedName("attributes") val attributes: MangaDexChapterAttributes,
    @SerializedName("relationships") val relationships: List<Relationship> = emptyList()
)

data class MangaDexChapterAttributes(
    @SerializedName("volume") val volume: String? = null,
    @SerializedName("chapter") val chapter: String? = null,
    @SerializedName("title") val title: String? = null,
    @SerializedName("translatedLanguage") val translatedLanguage: String = "",
    @SerializedName("externalUrl") val externalUrl: String? = null,
    @SerializedName("publishAt") val publishAt: String = "",
    @SerializedName("readableAt") val readableAt: String = "",
    @SerializedName("createdAt") val createdAt: String = "",
    @SerializedName("updatedAt") val updatedAt: String = "",
    @SerializedName("pages") val pages: Int = 0,
    @SerializedName("version") val version: Int = 1
)

/**
 * Represents a MangaDex cover art entity.
 */
data class MangaDexCover(
    @SerializedName("id") val id: String,
    @SerializedName("type") val type: String = "cover_art",
    @SerializedName("attributes") val attributes: MangaDexCoverAttributes
)

data class MangaDexCoverAttributes(
    @SerializedName("description") val description: String = "",
    @SerializedName("volume") val volume: String? = null,
    @SerializedName("fileName") val fileName: String,
    @SerializedName("locale") val locale: String = "",
    @SerializedName("createdAt") val createdAt: String = "",
    @SerializedName("updatedAt") val updatedAt: String = "",
    @SerializedName("version") val version: Int = 1
)

/**
 * Represents a MangaDex author/artist entity.
 */
data class MangaDexAuthor(
    @SerializedName("id") val id: String,
    @SerializedName("type") val type: String = "author",
    @SerializedName("attributes") val attributes: MangaDexAuthorAttributes
)

data class MangaDexAuthorAttributes(
    @SerializedName("name") val name: String,
    @SerializedName("imageUrl") val imageUrl: String? = null,
    @SerializedName("biography") val biography: Map<String, String> = emptyMap(),
    @SerializedName("twitter") val twitter: String? = null,
    @SerializedName("pixiv") val pixiv: String? = null,
    @SerializedName("melonBook") val melonBook: String? = null,
    @SerializedName("fanBox") val fanBox: String? = null,
    @SerializedName("booth") val booth: String? = null,
    @SerializedName("nicoVideo") val nicoVideo: String? = null,
    @SerializedName("skeb") val skeb: String? = null,
    @SerializedName("fantia") val fantia: String? = null,
    @SerializedName("tumblr") val tumblr: String? = null,
    @SerializedName("youtube") val youtube: String? = null,
    @SerializedName("weibo") val weibo: String? = null,
    @SerializedName("naver") val naver: String? = null,
    @SerializedName("website") val website: String? = null,
    @SerializedName("createdAt") val createdAt: String = "",
    @SerializedName("updatedAt") val updatedAt: String = "",
    @SerializedName("version") val version: Int = 1
)

/**
 * Response from the MangaDex at-home server endpoint.
 * Used to construct page image URLs for reading chapters.
 */
data class AtHomeResponse(
    @SerializedName("result") val result: String,
    @SerializedName("baseUrl") val baseUrl: String,
    @SerializedName("chapter") val chapter: AtHomeChapter
)

data class AtHomeChapter(
    @SerializedName("hash") val hash: String,
    @SerializedName("data") val data: List<String>,
    @SerializedName("dataSaver") val dataSaver: List<String>
)

/**
 * Represents a relationship entry in MangaDex API responses.
 * The [attributes] field is a generic map that varies based on the [type].
 */
data class Relationship(
    @SerializedName("id") val id: String,
    @SerializedName("type") val type: String,
    @SerializedName("related") val related: String? = null,
    @SerializedName("attributes") val attributes: Map<String, Any>? = null
)
