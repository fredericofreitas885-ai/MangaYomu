package com.mangayomu.data.database.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "history")
data class HistoryEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val mangaId: String,
    val chapterId: String,
    val sourceId: String,
    val readAt: Long
)
