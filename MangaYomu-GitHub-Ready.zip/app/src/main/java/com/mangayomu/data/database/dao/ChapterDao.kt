package com.mangayomu.data.database.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.mangayomu.data.database.entity.ChapterEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface ChapterDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(chapters: List<ChapterEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertChapter(chapter: ChapterEntity)

    @Query("SELECT * FROM chapters WHERE mangaId = :mangaId ORDER BY chapterNumber ASC")
    fun getChaptersForManga(mangaId: String): Flow<List<ChapterEntity>>

    @Query("SELECT * FROM chapters WHERE mangaId = :mangaId ORDER BY chapterNumber ASC")
    suspend fun getChaptersForMangaSync(mangaId: String): List<ChapterEntity>

    @Query("SELECT * FROM chapters WHERE id = :chapterId LIMIT 1")
    suspend fun getChapterById(chapterId: String): ChapterEntity?

    @Query("UPDATE chapters SET isRead = :isRead, lastPageRead = :lastPage WHERE id = :chapterId AND mangaId = :mangaId")
    suspend fun updateReadStatus(chapterId: String, mangaId: String, isRead: Boolean, lastPage: Int)

    @Query("UPDATE chapters SET isDownloaded = :isDownloaded WHERE id = :chapterId")
    suspend fun updateDownloadedStatus(chapterId: String, isDownloaded: Boolean)

    @Query("DELETE FROM chapters WHERE mangaId = :mangaId")
    suspend fun deleteChaptersForManga(mangaId: String)

    @Query("SELECT COUNT(*) FROM chapters WHERE mangaId = :mangaId")
    suspend fun getChapterCountForManga(mangaId: String): Int

    @Query("SELECT COUNT(*) FROM chapters WHERE mangaId = :mangaId AND isRead = 1")
    suspend fun getReadChapterCountForManga(mangaId: String): Int
}
