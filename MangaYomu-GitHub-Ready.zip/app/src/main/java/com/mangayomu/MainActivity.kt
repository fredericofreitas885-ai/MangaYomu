package com.mangayomu

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.mangayomu.ui.navigation.MangaYomuNavHost
import com.mangayomu.ui.theme.MangaYomuTheme
import dagger.hilt.android.AndroidEntryPoint

/**
 * Single Activity entry point for MangaYomu.
 * Uses Jetpack Compose for the entire UI with edge-to-edge rendering.
 */
@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MangaYomuTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    MangaYomuNavHost()
                }
            }
        }
    }
}
