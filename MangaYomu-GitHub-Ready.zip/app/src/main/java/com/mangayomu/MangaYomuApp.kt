package com.mangayomu

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

/**
 * Main Application class for MangaYomu.
 * Annotated with @HiltAndroidApp to enable Hilt dependency injection.
 */
@HiltAndroidApp
class MangaYomuApp : Application()
