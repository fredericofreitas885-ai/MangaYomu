package com.mangayomu.ui.library

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.mangayomu.domain.model.Category
import com.mangayomu.domain.model.Manga
import com.mangayomu.domain.repository.CategoryRepository
import com.mangayomu.domain.repository.MangaRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

data class LibraryUiState(
    val libraryManga: List<Manga> = emptyList(),
    val categories: List<Category> = emptyList(),
    val selectedCategory: Category? = null,
    val isLoading: Boolean = true
)

@HiltViewModel
class LibraryViewModel @Inject constructor(
    private val mangaRepository: MangaRepository,
    private val categoryRepository: CategoryRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(LibraryUiState())
    val uiState: StateFlow<LibraryUiState> = _uiState.asStateFlow()

    private var allLibraryManga: List<Manga> = emptyList()

    init {
        observeLibrary()
    }

    private fun observeLibrary() {
        viewModelScope.launch {
            combine(
                mangaRepository.getLibraryManga(),
                categoryRepository.getCategories()
            ) { manga, categories ->
                Pair(manga, categories)
            }.collect { (manga, categories) ->
                allLibraryManga = manga
                val currentCategory = _uiState.value.selectedCategory
                val filtered = if (currentCategory == null) {
                    manga
                } else {
                    categoryRepository.getMangaForCategory(currentCategory.id)
                    // or filter by category
                    manga
                }

                _uiState.update { state ->
                    state.copy(
                        libraryManga = filtered,
                        categories = categories,
                        isLoading = false
                    )
                }
            }
        }
    }

    fun selectCategory(category: Category?) {
        _uiState.update { it.copy(selectedCategory = category) }
        viewModelScope.launch {
            if (category == null) {
                _uiState.update { it.copy(libraryManga = allLibraryManga) }
            } else {
                categoryRepository.getMangaForCategory(category.id).collect { catManga ->
                    _uiState.update { it.copy(libraryManga = catManga) }
                }
            }
        }
    }

    fun createCategory(name: String) {
        if (name.isBlank()) return
        viewModelScope.launch {
            categoryRepository.createCategory(name.trim())
        }
    }

    fun deleteCategory(categoryId: Long) {
        viewModelScope.launch {
            categoryRepository.deleteCategory(categoryId)
            if (_uiState.value.selectedCategory?.id == categoryId) {
                selectCategory(null)
            }
        }
    }
}
