package com.mangayomu.ui.navigation

/**
 * Sealed class representing all navigation routes in MangaYomu.
 */
sealed class Screen(val route: String) {

    // Bottom navigation destinations
    data object Explore : Screen("explore")
    data object Library : Screen("library")
    data object History : Screen("history")
    data object Downloads : Screen("downloads")
    data object Settings : Screen("settings")

    // Detail screens
    data object MangaDetails : Screen("manga_details/{mangaId}/{sourceId}") {
        fun createRoute(mangaId: String, sourceId: String): String {
            return "manga_details/$mangaId/$sourceId"
        }
    }

    data object Reader : Screen("reader/{mangaId}/{chapterId}/{sourceId}") {
        fun createRoute(mangaId: String, chapterId: String, sourceId: String): String {
            return "reader/$mangaId/$chapterId/$sourceId"
        }
    }
}
