package com.mangayomu.ui.downloads

import androidx.lifecycle.ViewModel
import com.mangayomu.data.download.Download
import com.mangayomu.data.download.DownloadManager
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.StateFlow
import javax.inject.Inject

@HiltViewModel
class DownloadsViewModel @Inject constructor(
    private val downloadManager: DownloadManager
) : ViewModel() {

    val downloads: StateFlow<List<Download>> = downloadManager.downloads

    fun cancelDownload(chapterId: String) {
        downloadManager.cancelDownload(chapterId)
    }

    fun deleteDownload(mangaId: String, chapterId: String) {
        downloadManager.deleteDownload(mangaId, chapterId)
    }
}
