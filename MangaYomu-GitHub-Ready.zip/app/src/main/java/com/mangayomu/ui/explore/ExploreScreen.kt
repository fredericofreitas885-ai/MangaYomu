package com.mangayomu.ui.explore

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.Language
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.mangayomu.ui.components.ErrorMessage
import com.mangayomu.ui.components.LoadingIndicator
import com.mangayomu.ui.components.MangaGridItem
import com.mangayomu.ui.components.SearchBar

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExploreScreen(
    onMangaClick: (mangaId: String, sourceId: String) -> Unit,
    viewModel: ExploreViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsState()
    var sourceMenuExpanded by remember { mutableStateOf(false) }
    val gridState = rememberLazyGridState()

    // Detect when scrolling near the bottom to trigger pagination
    val shouldLoadMore by remember {
        derivedStateOf {
            val totalItemsCount = gridState.layoutInfo.totalItemsCount
            val lastVisibleItemIndex = gridState.layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: 0
            totalItemsCount > 0 && lastVisibleItemIndex >= totalItemsCount - 6
        }
    }

    LaunchedEffect(shouldLoadMore) {
        if (shouldLoadMore && uiState.hasNextPage && !uiState.isLoading) {
            viewModel.loadNextPage()
        }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        TopAppBar(
            title = {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "MangaYomu",
                        style = MaterialTheme.typography.titleLarge,
                        modifier = Modifier.weight(1f)
                    )

                    // Source selector button
                    Box {
                        OutlinedButton(
                            onClick = { sourceMenuExpanded = true },
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Language,
                                contentDescription = null,
                                modifier = Modifier.padding(end = 4.dp)
                            )
                            Text(text = uiState.selectedSource?.name ?: "Sources")
                            Icon(imageVector = Icons.Default.ArrowDropDown, contentDescription = null)
                        }

                        DropdownMenu(
                            expanded = sourceMenuExpanded,
                            onDismissRequest = { sourceMenuExpanded = false }
                        ) {
                            uiState.sources.forEach { source ->
                                DropdownMenuItem(
                                    text = { Text("${source.name} (${source.language.uppercase()})") },
                                    onClick = {
                                        viewModel.selectSource(source.id)
                                        sourceMenuExpanded = false
                                    }
                                )
                            }
                        }
                    }
                }
            }
        )

        TabRow(selectedTabIndex = uiState.currentTab.ordinal) {
            ExploreTab.entries.forEach { tab ->
                Tab(
                    selected = uiState.currentTab == tab,
                    onClick = { viewModel.selectTab(tab) },
                    text = { Text(tab.label) }
                )
            }
        }

        if (uiState.currentTab == ExploreTab.SEARCH) {
            SearchBar(
                query = uiState.searchQuery,
                onQueryChange = { viewModel.updateSearchQuery(it) },
                onSearch = { viewModel.search(uiState.searchQuery) },
                placeholder = "Search manga in ${uiState.selectedSource?.name ?: "source"}..."
            )
        }

        Box(modifier = Modifier.weight(1f)) {
            when {
                uiState.isLoading && uiState.mangaList.isEmpty() -> {
                    LoadingIndicator()
                }
                uiState.error != null && uiState.mangaList.isEmpty() -> {
                    ErrorMessage(
                        message = uiState.error ?: "Error loading manga",
                        onRetry = {
                            when (uiState.currentTab) {
                                ExploreTab.POPULAR -> viewModel.loadPopular()
                                ExploreTab.LATEST -> viewModel.loadLatest()
                                ExploreTab.SEARCH -> viewModel.search(uiState.searchQuery)
                            }
                        }
                    )
                }
                uiState.mangaList.isEmpty() -> {
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = if (uiState.currentTab == ExploreTab.SEARCH) "Type to search manga" else "No manga found",
                            style = MaterialTheme.typography.bodyLarge,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                else -> {
                    LazyVerticalGrid(
                        columns = GridCells.Fixed(3),
                        state = gridState,
                        contentPadding = PaddingValues(8.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxSize()
                    ) {
                        items(uiState.mangaList) { manga ->
                            MangaGridItem(
                                manga = manga,
                                onClick = { onMangaClick(manga.id, manga.sourceId) }
                            )
                        }

                        if (uiState.isLoading) {
                            item {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(16.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    LoadingIndicator()
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
