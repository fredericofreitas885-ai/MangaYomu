package com.mangayomu.ui.details

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.mangayomu.data.download.DownloadManager
import com.mangayomu.data.download.DownloadRequest
import com.mangayomu.data.source.SourceManager
import com.mangayomu.domain.model.Chapter
import com.mangayomu.domain.model.Manga
import com.mangayomu.domain.repository.ChapterRepository
import com.mangayomu.domain.repository.MangaRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

data class MangaDetailsUiState(
    val manga: Manga? = null,
    val chapters: List<Chapter> = emptyList(),
    val isInLibrary: Boolean = false,
    val isLoading: Boolean = true,
    val error: String? = null
)

@HiltViewModel
class MangaDetailsViewModel @Inject constructor(
    savedStateHandle: SavedStateHandle,
    private val sourceManager: SourceManager,
    private val mangaRepository: MangaRepository,
    private val chapterRepository: ChapterRepository,
    private val downloadManager: DownloadManager
) : ViewModel() {

    val mangaId: String = checkNotNull(savedStateHandle["mangaId"])
    val sourceId: String = checkNotNull(savedStateHandle["sourceId"])

    private val _uiState = MutableStateFlow(MangaDetailsUiState())
    val uiState: StateFlow<MangaDetailsUiState> = _uiState.asStateFlow()

    init {
        loadMangaDetails()
        observeLibraryStatus()
        observeLocalChapters()
    }

    private fun observeLibraryStatus() {
        viewModelScope.launch {
            val inLib = mangaRepository.isInLibrary(mangaId)
            _uiState.update { it.copy(isInLibrary = inLib) }
        }
    }

    private fun observeLocalChapters() {
        viewModelScope.launch {
            chapterRepository.getChaptersForManga(mangaId).collect { localChapters ->
                if (localChapters.isNotEmpty()) {
                    _uiState.update { it.copy(chapters = localChapters) }
                }
            }
        }
    }

    fun loadMangaDetails() {
        _uiState.update { it.copy(isLoading = true, error = null) }

        viewModelScope.launch {
            try {
                val source = sourceManager.getSource(sourceId)
                    ?: throw IllegalStateException("Source not found: $sourceId")

                val baseManga = mangaRepository.getMangaByIdSync(mangaId, sourceId)
                    ?: Manga(id = mangaId, title = "Manga", coverUrl = "", sourceId = sourceId)

                val detailedManga = source.getMangaDetails(baseManga)
                _uiState.update { it.copy(manga = detailedManga) }

                val chapters = source.getChapterList(detailedManga)
                chapterRepository.saveChapters(chapters)
                _uiState.update {
                    it.copy(
                        manga = detailedManga,
                        chapters = chapters,
                        isLoading = false
                    )
                }
            } catch (e: Exception) {
                _uiState.update {
                    it.copy(
                        isLoading = false,
                        error = e.message ?: "Failed to load manga details"
                    )
                }
            }
        }
    }

    fun toggleLibrary() {
        val manga = _uiState.value.manga ?: return
        viewModelScope.launch {
            val currentlyInLibrary = _uiState.value.isInLibrary
            if (currentlyInLibrary) {
                mangaRepository.removeFromLibrary(manga.id)
                _uiState.update { it.copy(isInLibrary = false) }
            } else {
                mangaRepository.addToLibrary(manga)
                _uiState.update { it.copy(isInLibrary = true) }
            }
        }
    }

    fun downloadChapter(chapter: Chapter) {
        val manga = _uiState.value.manga ?: return
        downloadManager.enqueue(
            DownloadRequest(
                mangaId = manga.id,
                chapterId = chapter.id,
                sourceId = manga.sourceId,
                mangaTitle = manga.title,
                chapterTitle = chapter.title
            )
        )
    }

    fun downloadAllChapters() {
        val manga = _uiState.value.manga ?: return
        _uiState.value.chapters.forEach { chapter ->
            downloadManager.enqueue(
                DownloadRequest(
                    mangaId = manga.id,
                    chapterId = chapter.id,
                    sourceId = manga.sourceId,
                    mangaTitle = manga.title,
                    chapterTitle = chapter.title
                )
            )
        }
    }
}
