package com.mangayomu.ui.reader

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.mangayomu.data.download.DownloadManager
import com.mangayomu.data.source.SourceManager
import com.mangayomu.domain.model.Chapter
import com.mangayomu.domain.model.Page
import com.mangayomu.domain.repository.ChapterRepository
import com.mangayomu.domain.repository.HistoryRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

data class ReaderUiState(
    val mangaId: String = "",
    val chapterId: String = "",
    val sourceId: String = "",
    val chapterTitle: String = "",
    val pages: List<Page> = emptyList(),
    val currentPage: Int = 0,
    val readingMode: ReadingMode = ReadingMode.RIGHT_TO_LEFT,
    val showControls: Boolean = true,
    val isLoading: Boolean = true,
    val error: String? = null,
    val nextChapterId: String? = null,
    val prevChapterId: String? = null
)

@HiltViewModel
class ReaderViewModel @Inject constructor(
    savedStateHandle: SavedStateHandle,
    private val sourceManager: SourceManager,
    private val chapterRepository: ChapterRepository,
    private val downloadManager: DownloadManager,
    private val historyRepository: HistoryRepository
) : ViewModel() {

    private val mangaId: String = checkNotNull(savedStateHandle["mangaId"])
    private val initialChapterId: String = checkNotNull(savedStateHandle["chapterId"])
    private val sourceId: String = checkNotNull(savedStateHandle["sourceId"])

    private val _uiState = MutableStateFlow(
        ReaderUiState(
            mangaId = mangaId,
            chapterId = initialChapterId,
            sourceId = sourceId
        )
    )
    val uiState: StateFlow<ReaderUiState> = _uiState.asStateFlow()

    init {
        loadChapter(initialChapterId)
        loadChapterSiblings(initialChapterId)
    }

    private fun loadChapterSiblings(chapterId: String) {
        viewModelScope.launch {
            try {
                val chapters = chapterRepository.getChaptersForManga(mangaId).first()
                val currentIndex = chapters.indexOfFirst { it.id == chapterId }
                if (currentIndex != -1) {
                    val prev = if (currentIndex > 0) chapters[currentIndex - 1].id else null
                    val next = if (currentIndex < chapters.size - 1) chapters[currentIndex + 1].id else null
                    _uiState.update { it.copy(prevChapterId = prev, nextChapterId = next) }
                }
            } catch (_: Exception) { }
        }
    }

    fun loadChapter(chapterId: String) {
        _uiState.update { it.copy(isLoading = true, error = null, chapterId = chapterId) }

        viewModelScope.launch {
            try {
                // Record history
                historyRepository.addToHistory(mangaId, chapterId, sourceId)

                // Check local downloads first
                if (downloadManager.isChapterDownloaded(mangaId, chapterId)) {
                    val downloadedPages = downloadManager.getDownloadedPages(mangaId, chapterId)
                    if (downloadedPages.isNotEmpty()) {
                        val chapter = chapterRepository.getChapterById(chapterId)
                        _uiState.update {
                            it.copy(
                                pages = downloadedPages,
                                chapterTitle = chapter?.title ?: "Chapter",
                                isLoading = false,
                                currentPage = chapter?.lastPageRead ?: 0
                            )
                        }
                        return@launch
                    }
                }

                // Online load from source
                val source = sourceManager.getSource(sourceId)
                    ?: throw IllegalStateException("Source not found: $sourceId")

                val chapter = chapterRepository.getChapterById(chapterId)
                    ?: Chapter(id = chapterId, mangaId = mangaId, title = "Chapter", sourceId = sourceId)

                val pages = source.getPageList(chapter)
                _uiState.update {
                    it.copy(
                        pages = pages,
                        chapterTitle = chapter.title.ifEmpty { "Chapter ${chapter.chapterNumber}" },
                        isLoading = false,
                        currentPage = chapter.lastPageRead.coerceAtMost(pages.size - 1).coerceAtLeast(0)
                    )
                }
            } catch (e: Exception) {
                _uiState.update {
                    it.copy(
                        isLoading = false,
                        error = e.message ?: "Failed to load chapter pages"
                    )
                }
            }
        }
    }

    fun onPageChanged(pageIndex: Int) {
        if (pageIndex < 0 || pageIndex >= _uiState.value.pages.size) return
        _uiState.update { it.copy(currentPage = pageIndex) }

        viewModelScope.launch {
            chapterRepository.markChapterRead(
                chapterId = _uiState.value.chapterId,
                lastPageRead = pageIndex
            )
        }
    }

    fun toggleControls() {
        _uiState.update { it.copy(showControls = !it.showControls) }
    }

    fun setReadingMode(mode: ReadingMode) {
        _uiState.update { it.copy(readingMode = mode) }
    }

    fun goToNextChapter() {
        val next = _uiState.value.nextChapterId ?: return
        loadChapter(next)
        loadChapterSiblings(next)
    }

    fun goToPrevChapter() {
        val prev = _uiState.value.prevChapterId ?: return
        loadChapter(prev)
        loadChapterSiblings(prev)
    }
}
