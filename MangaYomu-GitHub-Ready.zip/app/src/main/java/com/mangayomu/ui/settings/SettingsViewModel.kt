package com.mangayomu.ui.settings

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.mangayomu.data.source.CustomScraperSource
import com.mangayomu.data.source.CustomSourceConfig
import com.mangayomu.data.source.MangaSource
import com.mangayomu.data.source.SourceManager
import com.mangayomu.ui.reader.ReadingMode
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import javax.inject.Inject

enum class ThemeMode(val label: String) {
    SYSTEM("System Default"),
    LIGHT("Light"),
    DARK("Dark")
}

data class SettingsUiState(
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    val defaultReadingMode: ReadingMode = ReadingMode.RIGHT_TO_LEFT,
    val sources: List<MangaSource> = emptyList()
)

@HiltViewModel
class SettingsViewModel @Inject constructor(
    private val sourceManager: SourceManager,
    private val okHttpClient: OkHttpClient
) : ViewModel() {

    private val _uiState = MutableStateFlow(SettingsUiState())
    val uiState: StateFlow<SettingsUiState> = _uiState.asStateFlow()

    init {
        observeSources()
    }

    private fun observeSources() {
        viewModelScope.launch {
            sourceManager.sourcesFlow.collect { sources ->
                _uiState.update { it.copy(sources = sources) }
            }
        }
    }

    fun setThemeMode(mode: ThemeMode) {
        _uiState.update { it.copy(themeMode = mode) }
    }

    fun setDefaultReadingMode(mode: ReadingMode) {
        _uiState.update { it.copy(defaultReadingMode = mode) }
    }

    fun addCustomSource(
        name: String,
        baseUrl: String,
        popularPath: String,
        searchPath: String,
        itemSelector: String,
        titleSelector: String,
        coverSelector: String
    ) {
        val id = name.lowercase().replace(" ", "_").trim()
        val config = CustomSourceConfig(
            id = id,
            name = name.trim(),
            baseUrl = baseUrl.trim().removeSuffix("/"),
            popularPath = popularPath.trim(),
            searchPath = searchPath.trim(),
            mangaItemSelector = itemSelector.ifBlank { ".manga-item" },
            titleSelector = titleSelector.ifBlank { ".title a" },
            coverSelector = coverSelector.ifBlank { "img" }
        )

        val customSource = CustomScraperSource(okHttpClient, config)
        sourceManager.registerSource(customSource)
    }

    fun removeSource(sourceId: String) {
        sourceManager.unregisterSource(sourceId)
    }
}
