package com.mangayomu.ui.downloads

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.Divider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SuggestionChip
import androidx.compose.material3.SuggestionChipDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.mangayomu.data.download.DownloadStatus

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DownloadsScreen(
    viewModel: DownloadsViewModel = hiltViewModel()
) {
    val downloads by viewModel.downloads.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Downloads (${downloads.size})") }
            )
        }
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            if (downloads.isEmpty()) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "No downloads in progress or queued.",
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else {
                LazyColumn(modifier = Modifier.fillMaxSize()) {
                    items(downloads, key = { it.chapterId }) { download ->
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = download.mangaTitle,
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = download.chapterTitle,
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }

                                val (statusColor, statusLabel) = when (download.status) {
                                    DownloadStatus.QUEUED -> Pair(Color.Gray, "Queued")
                                    DownloadStatus.DOWNLOADING -> Pair(MaterialTheme.colorScheme.primary, "${download.progress}%")
                                    DownloadStatus.COMPLETED -> Pair(Color(0xFF2E7D32), "Completed")
                                    DownloadStatus.ERROR -> Pair(MaterialTheme.colorScheme.error, "Error")
                                }

                                SuggestionChip(
                                    onClick = { },
                                    label = { Text(statusLabel) },
                                    colors = SuggestionChipDefaults.suggestionChipColors(
                                        labelColor = statusColor
                                    )
                                )

                                IconButton(
                                    onClick = {
                                        if (download.status == DownloadStatus.COMPLETED) {
                                            viewModel.deleteDownload(download.mangaId, download.chapterId)
                                        } else {
                                            viewModel.cancelDownload(download.chapterId)
                                        }
                                    }
                                ) {
                                    Icon(
                                        imageVector = if (download.status == DownloadStatus.COMPLETED) Icons.Default.Delete else Icons.Default.Close,
                                        contentDescription = "Cancel or delete",
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                            }

                            if (download.status == DownloadStatus.DOWNLOADING) {
                                Spacer(modifier = Modifier.height(8.dp))
                                LinearProgressIndicator(
                                    progress = download.progress / 100f,
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                        }
                        Divider()
                    }
                }
            }
        }
    }
}
