package com.mangayomu.ui.navigation

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.LibraryBooks
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.outlined.Download
import androidx.compose.material.icons.outlined.Explore
import androidx.compose.material.icons.outlined.History
import androidx.compose.material.icons.outlined.LibraryBooks
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.mangayomu.R
import com.mangayomu.ui.details.MangaDetailsScreen
import com.mangayomu.ui.downloads.DownloadsScreen
import com.mangayomu.ui.explore.ExploreScreen
import com.mangayomu.ui.history.HistoryScreen
import com.mangayomu.ui.library.LibraryScreen
import com.mangayomu.ui.reader.ReaderScreen
import com.mangayomu.ui.settings.SettingsScreen

/**
 * Data class representing a bottom navigation item.
 */
data class BottomNavItem(
    val screen: Screen,
    val labelResId: Int,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector
)

/**
 * Bottom navigation items configuration.
 */
val bottomNavItems = listOf(
    BottomNavItem(
        screen = Screen.Explore,
        labelResId = R.string.nav_explore,
        selectedIcon = Icons.Filled.Explore,
        unselectedIcon = Icons.Outlined.Explore
    ),
    BottomNavItem(
        screen = Screen.Library,
        labelResId = R.string.nav_library,
        selectedIcon = Icons.Filled.LibraryBooks,
        unselectedIcon = Icons.Outlined.LibraryBooks
    ),
    BottomNavItem(
        screen = Screen.History,
        labelResId = R.string.nav_history,
        selectedIcon = Icons.Filled.History,
        unselectedIcon = Icons.Outlined.History
    ),
    BottomNavItem(
        screen = Screen.Downloads,
        labelResId = R.string.nav_downloads,
        selectedIcon = Icons.Filled.Download,
        unselectedIcon = Icons.Outlined.Download
    ),
    BottomNavItem(
        screen = Screen.Settings,
        labelResId = R.string.nav_settings,
        selectedIcon = Icons.Filled.Settings,
        unselectedIcon = Icons.Outlined.Settings
    )
)

/**
 * Main navigation host composable for MangaYomu.
 * Sets up a Scaffold with bottom navigation and a NavHost with all routes.
 */
@Composable
fun MangaYomuNavHost() {
    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentDestination = navBackStackEntry?.destination

    // Determine if the bottom bar should be visible
    val bottomBarRoutes = bottomNavItems.map { it.screen.route }
    val showBottomBar = currentDestination?.route in bottomBarRoutes

    Scaffold(
        bottomBar = {
            if (showBottomBar) {
                NavigationBar {
                    bottomNavItems.forEach { item ->
                        val selected = currentDestination?.hierarchy?.any {
                            it.route == item.screen.route
                        } == true

                        NavigationBarItem(
                            icon = {
                                Icon(
                                    imageVector = if (selected) item.selectedIcon else item.unselectedIcon,
                                    contentDescription = stringResource(item.labelResId)
                                )
                            },
                            label = { Text(text = stringResource(item.labelResId)) },
                            selected = selected,
                            onClick = {
                                navController.navigate(item.screen.route) {
                                    popUpTo(navController.graph.findStartDestination().id) {
                                        saveState = true
                                    }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            }
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = Screen.Explore.route,
            modifier = Modifier.padding(innerPadding)
        ) {
            // Bottom navigation destinations
            composable(Screen.Explore.route) {
                ExploreScreen(
                    onMangaClick = { mangaId, sourceId ->
                        navController.navigate(Screen.MangaDetails.createRoute(mangaId, sourceId))
                    }
                )
            }

            composable(Screen.Library.route) {
                LibraryScreen(
                    onMangaClick = { mangaId, sourceId ->
                        navController.navigate(Screen.MangaDetails.createRoute(mangaId, sourceId))
                    }
                )
            }

            composable(Screen.History.route) {
                HistoryScreen(
                    onMangaClick = { mangaId, sourceId ->
                        navController.navigate(Screen.MangaDetails.createRoute(mangaId, sourceId))
                    }
                )
            }

            composable(Screen.Downloads.route) {
                DownloadsScreen()
            }

            composable(Screen.Settings.route) {
                SettingsScreen()
            }

            // Detail screens
            composable(
                route = Screen.MangaDetails.route,
                arguments = listOf(
                    navArgument("mangaId") { type = NavType.StringType },
                    navArgument("sourceId") { type = NavType.StringType }
                )
            ) { backStackEntry ->
                val mangaId = backStackEntry.arguments?.getString("mangaId") ?: return@composable
                val sourceId = backStackEntry.arguments?.getString("sourceId") ?: return@composable
                MangaDetailsScreen(
                    mangaId = mangaId,
                    sourceId = sourceId,
                    onBackClick = { navController.popBackStack() },
                    onChapterClick = { chapterId ->
                        navController.navigate(Screen.Reader.createRoute(mangaId, chapterId, sourceId))
                    }
                )
            }

            composable(
                route = Screen.Reader.route,
                arguments = listOf(
                    navArgument("mangaId") { type = NavType.StringType },
                    navArgument("chapterId") { type = NavType.StringType },
                    navArgument("sourceId") { type = NavType.StringType }
                )
            ) { backStackEntry ->
                val mangaId = backStackEntry.arguments?.getString("mangaId") ?: return@composable
                val chapterId = backStackEntry.arguments?.getString("chapterId") ?: return@composable
                val sourceId = backStackEntry.arguments?.getString("sourceId") ?: return@composable
                ReaderScreen(
                    mangaId = mangaId,
                    chapterId = chapterId,
                    sourceId = sourceId,
                    onBackClick = { navController.popBackStack() }
                )
            }
        }
    }
}
