package com.mangayomu.ui.explore

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.mangayomu.data.source.MangaSource
import com.mangayomu.data.source.SourceManager
import com.mangayomu.domain.model.Manga
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

enum class ExploreTab(val label: String) {
    POPULAR("Popular"),
    LATEST("Latest"),
    SEARCH("Search")
}

data class ExploreUiState(
    val sources: List<MangaSource> = emptyList(),
    val selectedSource: MangaSource? = null,
    val mangaList: List<Manga> = emptyList(),
    val searchQuery: String = "",
    val isLoading: Boolean = false,
    val error: String? = null,
    val currentPage: Int = 0,
    val hasNextPage: Boolean = false,
    val currentTab: ExploreTab = ExploreTab.POPULAR
)

@HiltViewModel
class ExploreViewModel @Inject constructor(
    private val sourceManager: SourceManager
) : ViewModel() {

    private val _uiState = MutableStateFlow(ExploreUiState())
    val uiState: StateFlow<ExploreUiState> = _uiState.asStateFlow()

    init {
        observeSources()
    }

    private fun observeSources() {
        viewModelScope.launch {
            sourceManager.sourcesFlow.collect { sources ->
                _uiState.update { state ->
                    val selected = state.selectedSource?.let { current ->
                        sources.find { it.id == current.id }
                    } ?: sources.firstOrNull()

                    state.copy(
                        sources = sources,
                        selectedSource = selected
                    )
                }
                if (_uiState.value.mangaList.isEmpty()) {
                    loadPopular()
                }
            }
        }
    }

    fun selectSource(sourceId: String) {
        val source = sourceManager.getSource(sourceId) ?: return
        _uiState.update { it.copy(selectedSource = source, currentPage = 0, mangaList = emptyList()) }
        when (_uiState.value.currentTab) {
            ExploreTab.POPULAR -> loadPopular()
            ExploreTab.LATEST -> loadLatest()
            ExploreTab.SEARCH -> if (_uiState.value.searchQuery.isNotBlank()) search(_uiState.value.searchQuery)
        }
    }

    fun selectTab(tab: ExploreTab) {
        _uiState.update { it.copy(currentTab = tab) }
        when (tab) {
            ExploreTab.POPULAR -> loadPopular()
            ExploreTab.LATEST -> loadLatest()
            ExploreTab.SEARCH -> {
                // If there's an existing query, re-search, otherwise keep current list
            }
        }
    }

    fun updateSearchQuery(query: String) {
        _uiState.update { it.copy(searchQuery = query) }
    }

    fun loadPopular() {
        val source = _uiState.value.selectedSource ?: return
        _uiState.update { it.copy(isLoading = true, error = null, currentPage = 0, mangaList = emptyList(), currentTab = ExploreTab.POPULAR) }

        viewModelScope.launch {
            try {
                val result = source.getPopularManga(0)
                _uiState.update { state ->
                    state.copy(
                        mangaList = result.mangas,
                        hasNextPage = result.hasNextPage,
                        isLoading = false,
                        currentPage = 0
                    )
                }
            } catch (e: Exception) {
                _uiState.update { it.copy(isLoading = false, error = e.message ?: "Failed to load popular manga") }
            }
        }
    }

    fun loadLatest() {
        val source = _uiState.value.selectedSource ?: return
        _uiState.update { it.copy(isLoading = true, error = null, currentPage = 0, mangaList = emptyList(), currentTab = ExploreTab.LATEST) }

        viewModelScope.launch {
            try {
                val result = source.getLatestManga(0)
                _uiState.update { state ->
                    state.copy(
                        mangaList = result.mangas,
                        hasNextPage = result.hasNextPage,
                        isLoading = false,
                        currentPage = 0
                    )
                }
            } catch (e: Exception) {
                _uiState.update { it.copy(isLoading = false, error = e.message ?: "Failed to load latest manga") }
            }
        }
    }

    fun search(query: String) {
        val source = _uiState.value.selectedSource ?: return
        if (query.isBlank()) return
        _uiState.update { it.copy(isLoading = true, error = null, currentPage = 0, mangaList = emptyList(), currentTab = ExploreTab.SEARCH) }

        viewModelScope.launch {
            try {
                val result = source.searchManga(query, 0)
                _uiState.update { state ->
                    state.copy(
                        mangaList = result.mangas,
                        hasNextPage = result.hasNextPage,
                        isLoading = false,
                        currentPage = 0
                    )
                }
            } catch (e: Exception) {
                _uiState.update { it.copy(isLoading = false, error = e.message ?: "Search failed") }
            }
        }
    }

    fun loadNextPage() {
        val state = _uiState.value
        val source = state.selectedSource ?: return
        if (state.isLoading || !state.hasNextPage) return

        val nextPage = state.currentPage + 1
        _uiState.update { it.copy(isLoading = true) }

        viewModelScope.launch {
            try {
                val result = when (state.currentTab) {
                    ExploreTab.POPULAR -> source.getPopularManga(nextPage)
                    ExploreTab.LATEST -> source.getLatestManga(nextPage)
                    ExploreTab.SEARCH -> source.searchManga(state.searchQuery, nextPage)
                }

                _uiState.update { current ->
                    current.copy(
                        mangaList = current.mangaList + result.mangas,
                        hasNextPage = result.hasNextPage,
                        isLoading = false,
                        currentPage = nextPage
                    )
                }
            } catch (e: Exception) {
                _uiState.update { it.copy(isLoading = false, error = e.message) }
            }
        }
    }
}
