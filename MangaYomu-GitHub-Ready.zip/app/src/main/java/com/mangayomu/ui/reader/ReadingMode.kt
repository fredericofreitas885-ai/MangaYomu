package com.mangayomu.ui.reader

/**
 * Enum representing the available reading modes for the manga reader.
 */
enum class ReadingMode(val label: String) {
    LEFT_TO_RIGHT("Left to Right"),
    RIGHT_TO_LEFT("Right to Left"),
    WEBTOON("Webtoon")
}
